package com.cocopo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CocopoApisBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
