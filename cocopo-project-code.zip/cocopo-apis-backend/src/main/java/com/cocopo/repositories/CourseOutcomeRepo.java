package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.ids.CourseOutcomeId;
import com.cocopo.models.CourseOutcome;

public interface CourseOutcomeRepo extends JpaRepositoryImplementation<CourseOutcome, CourseOutcomeId>{

	@Query("SELECT co FROM CourseOutcome co WHERE co.course_code = :course_code AND co.co_id = :co_id")
	CourseOutcome findByOutcome(String course_code, String co_id);

	@Query("SELECT co FROM CourseOutcome co WHERE co.course_code = :course_code")
	List<CourseOutcome> findOutcomeByCode(@Param("course_code") String course_code);

	@Query("SELECT co.course_code FROM CourseOutcome co")
	List<String> findAllCourseCodes();
	
}
