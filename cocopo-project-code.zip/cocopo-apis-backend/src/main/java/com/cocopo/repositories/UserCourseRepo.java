package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.ids.UserCourseId;
import com.cocopo.models.UserCourse;

public interface UserCourseRepo extends JpaRepositoryImplementation<UserCourse, UserCourseId> {

	@Query("SELECT uc FROM UserCourse uc WHERE uc.assigned_faculty = :assigned_faculty AND uc.course_code = :course_code")
	UserCourse findUserCourse(@Param("assigned_faculty") String assigned_faculty, @Param("course_code") String course_code);

	@Query("SELECT uc FROM UserCourse uc WHERE uc.course_code = :course_code")
	List<UserCourse> findUserByCourse(@Param("course_code") String course_code);

	@Query("SELECT uc FROM UserCourse uc WHERE uc.assigned_faculty = :assigned_faculty")
	List<UserCourse> findUserById(@Param("assigned_faculty") String assigned_faculty);

}
