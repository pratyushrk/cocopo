package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.ids.ProgramAttainmentId;
import com.cocopo.models.ProgramAttainment;

public interface ProgramAttainmentRepo extends JpaRepositoryImplementation<ProgramAttainment, ProgramAttainmentId>{

	@Query("SELECT pa FROM ProgramAttainment pa WHERE pa.year = :year AND pa.co_id = :co_id AND pa.po_id = :po_id AND pa.course_code = :course_code")
	ProgramAttainment findByPAttainment(@Param("year") int year, @Param("co_id") String co_id, @Param("po_id") String po_id, @Param("course_code") String course_code);

	@Query("SELECT pa FROM ProgramAttainment pa WHERE pa.course_code = :course_code")
	List<ProgramAttainment> findPAttainmentByCode(@Param("course_code") String course_code);

	@Query("SELECT pa FROM ProgramAttainment pa WHERE pa.year = :year")
	List<ProgramAttainment> findPAttainmentByYear(@Param("year") int year);

}
