package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.ids.CourseObjectiveId;
import com.cocopo.models.CourseObjective;

public interface CourseObjectiveRepo extends JpaRepositoryImplementation<CourseObjective, CourseObjectiveId>{

	@Query("SELECT co FROM CourseObjective co WHERE co.course_code = :course_code AND co.cobj_id = :cobj_id")
    CourseObjective findByObjective(@Param("course_code") String course_code, @Param("cobj_id") String cobj_id);

    @Query("SELECT co FROM CourseObjective co WHERE co.course_code = :course_code")
    List<CourseObjective> findCObjectiveByCode(@Param("course_code") String course_code);

}
