package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.ids.CourseAttainmentId;
import com.cocopo.models.CourseAttainment;

public interface CourseAttainmentRepo extends JpaRepositoryImplementation<CourseAttainment, CourseAttainmentId> {

	@Query("SELECT ca FROM CourseAttainment ca WHERE ca.year = :year AND ca.co_id = :co_id AND ca.course_code = :course_code")
	CourseAttainment findByCAttainment(@Param("year") int year, @Param("co_id") String co_id, @Param("course_code") String course_code);

    @Query("SELECT ca FROM CourseAttainment ca WHERE ca.course_code = :course_code")
    List<CourseAttainment> findCAttainmentByCode(@Param("course_code") String course_code);

    @Query("SELECT ca FROM CourseAttainment ca WHERE ca.year = :year")
    List<CourseAttainment> findCAttainmentByYear(@Param("year") int year);

}
