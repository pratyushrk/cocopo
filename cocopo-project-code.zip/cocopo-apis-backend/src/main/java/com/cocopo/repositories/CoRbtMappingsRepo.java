package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.ids.CoRbtMappingId;
import com.cocopo.models.CoRbtMappings;

public interface CoRbtMappingsRepo extends JpaRepositoryImplementation<CoRbtMappings, CoRbtMappingId> {

	@Query("SELECT cr.rbt_id FROM CoRbtMappings cr WHERE cr.course_code = :course_code AND cr.co_id = :co_id")
	List<String> findRbtListByCode(@Param("course_code") String course_code, @Param("co_id") String co_id);

    @Query("SELECT cr FROM CoRbtMappings cr WHERE cr.course_code = :course_code AND cr.co_id = :co_id")
    List<CoRbtMappings> findRbtMappingsByCode(@Param("course_code") String course_code, @Param("co_id") String co_id);

    @Query("SELECT cr FROM CoRbtMappings cr WHERE cr.course_code = :course_code AND cr.co_id = :co_id AND cr.rbt_id = :rbt_id")
    CoRbtMappings findRbtMapping(@Param("course_code") String course_code, @Param("co_id") String co_id, @Param("rbt_id") String rbt_id);

    @Query("SELECT cr FROM CoRbtMappings cr WHERE cr.course_code = :course_code")
    List<CoRbtMappings> findRbtMappingsByCourse(@Param("course_code") String course_code);
}