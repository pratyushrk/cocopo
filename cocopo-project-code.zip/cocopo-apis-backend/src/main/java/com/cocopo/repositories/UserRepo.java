// to save data into database

package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.models.User;

public interface UserRepo extends JpaRepositoryImplementation<User, String>{

	@Query("SELECT u FROM User u WHERE u.fullname LIKE %:fullname%")
	List<User> findUserByFullname(@Param("fullname") String fullname); // parameter name, then parameter value

	@Query("SELECT u FROM User u WHERE u.username LIKE %:username%")
	List<User> findUserByUsername(@Param("username") String username);

	@Query("SELECT u FROM User u WHERE u.username LIKE :username")
	User findExactByUsername(@Param("username") String username);

}
