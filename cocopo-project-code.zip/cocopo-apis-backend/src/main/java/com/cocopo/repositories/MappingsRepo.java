package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.ids.MappingId;
import com.cocopo.models.Mappings;

public interface MappingsRepo extends JpaRepositoryImplementation<Mappings, MappingId>{

	@Query("SELECT m FROM Mappings m WHERE m.course_code = :course_code AND m.co_id = :co_id AND m.po_id = :po_id")
	Mappings findByMapping(@Param("course_code") String course_code, @Param("co_id") String co_id, @Param("po_id") String po_id);
	
	@Query("SELECT m FROM Mappings m WHERE m.course_code = :course_code")
	List<Mappings> findMappingByCode(@Param("course_code") String course_code);

}
