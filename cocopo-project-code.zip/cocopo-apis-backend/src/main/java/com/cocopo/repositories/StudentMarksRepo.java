package com.cocopo.repositories;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.cocopo.models.StudentMarks;

public interface StudentMarksRepo extends JpaRepositoryImplementation<StudentMarks, String> {

}
