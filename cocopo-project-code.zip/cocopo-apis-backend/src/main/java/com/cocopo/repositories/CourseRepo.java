package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.models.Course;

public interface CourseRepo extends JpaRepositoryImplementation<Course, String>{

	@Query("SELECT c FROM Course c WHERE c.course_name LIKE %:course_name%")
	List<Course> findCoursesByName(@Param("course_name") String course_name); // parameter name, then parameter value
	
	@Query("SELECT c FROM Course c WHERE c.course_code LIKE %:course_code%")
	List<Course> findCourseByCode(@Param("course_code") String course_code);

	@Query("SELECT c FROM Course c WHERE c.branch = :branch")
	List<Course> findCourseByBranch(@Param("branch") String branch);

	@Query("SELECT c FROM Course c WHERE c.course_code LIKE :course_code")
	Course findExactCourseByCode(@Param("course_code") String course_code);
	
}
