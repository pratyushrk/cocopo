package com.cocopo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;

import com.cocopo.ids.OptimizedCoId;
import com.cocopo.models.OptimizedCO;

public interface OptimizedCoRepo extends JpaRepositoryImplementation<OptimizedCO, OptimizedCoId> {

	@Query("SELECT oc FROM OptimizedCO oc WHERE oc.co_id = :co_id AND oc.status = 'selected'")
	OptimizedCO findSelectedOptimizedCO(@Param("co_id") String co_id);

	@Query("SELECT oc FROM OptimizedCO oc WHERE oc.co_id = :co_id AND oc.optimized_id = :optimized_id")
	OptimizedCO findOptimizedCO(@Param("co_id") String co_id, @Param("optimized_id") int optimized_id);

	@Query("SELECT oc FROM OptimizedCO oc WHERE oc.status = 'selected'")
	List<OptimizedCO> findAllSelectedOptimizedCOs();

	@Query("SELECT oc FROM OptimizedCO oc WHERE oc.co_id = :co_id")
	List<OptimizedCO> findOptimizedCOByCode(@Param("co_id") String co_id);

}
