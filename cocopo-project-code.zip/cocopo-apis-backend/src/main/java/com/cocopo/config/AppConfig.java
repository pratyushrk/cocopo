package com.cocopo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cocopo.utils.ExcelFormulaPusher;

@Configuration
public class AppConfig {
    @Bean
    ExcelFormulaPusher excelFormulaPusher() {
        return new ExcelFormulaPusher();
    }
}

