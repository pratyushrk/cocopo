package com.cocopo.payloads;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class CourseObjectiveDTO {

	private String course_code;
	private String cobj_id;	
	private String description;

}
