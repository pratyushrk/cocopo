package com.cocopo.payloads;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class ProgramAttainmentDTO {

	private int year;
	private String co_id;
	private String po_id;
	private String course_code;	
	private float program_attainment;
	
}
