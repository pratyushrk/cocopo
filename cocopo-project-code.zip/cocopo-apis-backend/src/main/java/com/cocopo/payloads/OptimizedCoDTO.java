package com.cocopo.payloads;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class OptimizedCoDTO {

	private String co_id;
	private int optimized_id;	
	private String description;
	private String status;
	
}
