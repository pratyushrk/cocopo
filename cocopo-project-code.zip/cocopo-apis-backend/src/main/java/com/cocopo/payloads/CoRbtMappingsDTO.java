package com.cocopo.payloads;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class CoRbtMappingsDTO {

	private String course_code;
	private String co_id;
	private String rbt_id;
}
