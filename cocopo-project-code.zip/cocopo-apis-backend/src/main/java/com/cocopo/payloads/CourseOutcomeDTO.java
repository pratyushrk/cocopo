package com.cocopo.payloads;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class CourseOutcomeDTO {

	private String course_code;
	private String co_id;	
	private String description;
	
}
