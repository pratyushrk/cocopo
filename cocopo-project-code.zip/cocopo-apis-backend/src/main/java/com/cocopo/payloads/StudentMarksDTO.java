package com.cocopo.payloads;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class StudentMarksDTO {

	private String srn;
	private String name;
	private float isa1;
	private float isa2;
	private float isa3;
	private float isa4;
	private float isa5;
	private float esa;
	
}
