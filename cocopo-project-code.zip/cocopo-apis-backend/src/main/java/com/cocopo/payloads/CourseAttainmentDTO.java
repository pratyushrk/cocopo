package com.cocopo.payloads;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class CourseAttainmentDTO {

	private int year;
	private String course_code;
	private String co_id;	
	private float course_attainment;
}
