package com.cocopo.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.ss.usermodel.*;


public class ExcelFormulaPusher {
	
    DataFormatter dataFormatter = new DataFormatter();
	
	public Workbook pushRowsToTemplate(File uploadedFile) throws IOException {
        try {
            // Load the existing Formula_template workbook
        	// Use the class loader to load the resource
        	ClassLoader classLoader = getClass().getClassLoader();
        	InputStream templateStream = classLoader.getResourceAsStream("templates/Formula_template.xlsx");

            // Load the uploaded Excel file
            FileInputStream inputStream = new FileInputStream(uploadedFile);
            Workbook workbook = WorkbookFactory.create(inputStream);
            Sheet marksSheet = workbook.getSheetAt(0);

            // Clone the Formula_template workbook to create a temporary copy
            Workbook modifiedWorkbook = WorkbookFactory.create(templateStream);
            Sheet templateSheetCopy = modifiedWorkbook.getSheetAt(0);

            int templateRowIndex = 0; // Start copying markSheet values to the first row of the template copy

            for (int rowIndex = 0; rowIndex <= marksSheet.getLastRowNum(); rowIndex++) {
                Row sourceRow = marksSheet.getRow(rowIndex);
                Row destinationRow = templateSheetCopy.getRow(templateRowIndex);

                if (destinationRow == null) {
                    // If the row doesn't exist in the template copy, create it
                    destinationRow = templateSheetCopy.createRow(templateRowIndex);
                }
                
                // Copy the values from the first 8 columns
                for (int colIndex = 0; colIndex < Math.min(sourceRow.getLastCellNum(), 8); colIndex++) {
                    Cell sourceCell = sourceRow.getCell(colIndex);
                    Cell destinationCell = destinationRow.createCell(colIndex);

                    if (colIndex < 2) {
                        // For the first 2 cells, directly copy the string value
                        destinationCell.setCellValue(sourceCell.getStringCellValue());
                    } else {
                        // For the remaining cells, copy the formula itself
                        if (sourceCell.getCellType() == CellType.FORMULA) {
                            destinationCell.setCellFormula(sourceCell.getCellFormula());
                        } else {
                            // If it's not a formula cell, directly copy the value
                            destinationCell.setCellValue(sourceCell.getStringCellValue());
                        }
                    }
                }

                // Increment the templateRowIndex for the next iteration
                templateRowIndex++;
            }

            // Save the modified workbook to the upload directory
            String uploadDirectory = "D:\\COCOPO-project\\sts-4.20.0.RELEASE\\uploadsToWebsite";
            String modifiedFileName = "Modified_Formula_template.xlsx";
            String modifiedFilePath = uploadDirectory + File.separator + modifiedFileName;

            // Check if the file already exists, and delete it if it does
            File modifiedFile = new File(modifiedFilePath);
            if (modifiedFile.exists()) {
                modifiedFile.delete();
            }

            // Create a new file output stream
            try (FileOutputStream outputStream = new FileOutputStream(modifiedFile)) {
                modifiedWorkbook.write(outputStream);
            } catch (IOException e) {
                e.printStackTrace(); // Handle the exception appropriately (log it, throw it, etc.)
            } finally {
                try {
                    if (modifiedWorkbook != null) {
                        modifiedWorkbook.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace(); 
                }
            }

            System.out.println("Modified workbook saved at: " + modifiedFilePath);
            
            // Return the modified workbook
            return modifiedWorkbook; 

        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
            // You might want to throw an exception or handle it according to your requirements
            return null;
        }
	}
	
}

