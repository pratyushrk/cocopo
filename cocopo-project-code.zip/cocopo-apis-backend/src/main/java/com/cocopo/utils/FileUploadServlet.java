package com.cocopo.utils;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.UUID;

@WebServlet("/upload")
@MultipartConfig(fileSizeThreshold = 1024 * 1024, // 1MB
                 maxFileSize = 10 * 1024 * 1024, // 10MB
                 maxRequestSize = 20 * 1024 * 1024) // 20MB
public class FileUploadServlet extends HttpServlet {
	private static final String UPLOAD_DIRECTORY = "/uploadsToWebsite/";
	
	private File uploadedFile;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Collection<Part> parts = request.getParts();

        for (Part part : parts) {
            String fileName = getSubmittedFileName(part);

            if (fileName != null) {
                // Sanitize and validate the file name
                fileName = sanitizeFileName(fileName);
                
                // Validate file type (e.g., allow only certain extensions)
                if (!isFileTypeAllowed(fileName)) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid file type.");
                    return;
                }

                // Generate a unique file name (discard original file name)
                String uniqueFileName = generateUniqueFileName(fileName);
                
                //write/save file to specified path or location
                File uploadedFile = new File(UPLOAD_DIRECTORY, uniqueFileName);
                part.write(uploadedFile.getPath());

            }
        }
    }

    private boolean isFileTypeAllowed(String fileName) {
        return fileName.toLowerCase().endsWith(".xlsx") || fileName.toLowerCase().endsWith(".csv");
    }

    private String generateUniqueFileName(String fileName) {
        // Generate a unique file name, for example, using a UUID.
        String extension = "";
        int dotIndex = fileName.lastIndexOf(".");	//extension is the part after *last* dot
        if (dotIndex != -1) {	//dotIndex=-1 means no dot or extension
            extension = fileName.substring(dotIndex);	//save the substring after dot as the extension
        }
        return UUID.randomUUID().toString() + extension;	//join the 128-bit generated *unique* identifier and extension and return 
    }

    private String getSubmittedFileName(Part part) {
        for (String cd : part.getHeader("content-disposition").split(";")) {
            if (cd.trim().startsWith("filename")) {
                String fileName = cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
                return fileName;
            }
        }
        return null;
    }

    private String sanitizeFileName(String fileName) {
        // Remove potentially dangerous characters (characters other than the ones in the square bracket) and replace with underscores
        return fileName.replaceAll("[^a-zA-Z0-9\\.\\-]", "_");
    }
    
    public File getUploadedFile() {
    	return uploadedFile;
    }
}
