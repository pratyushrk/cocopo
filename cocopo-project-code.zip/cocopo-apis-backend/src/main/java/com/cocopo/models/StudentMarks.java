package com.cocopo.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "student_marks")
@Entity
@NoArgsConstructor
@Setter
@Getter
public class StudentMarks {

	@Id
	private String srn;
	
	private String name;
	private float isa1;
	private float isa2;
	private float isa3;
	private float isa4;
	private float isa5;
	private float esa;
	
}
