package com.cocopo.models;

import com.cocopo.ids.CourseOutcomeId;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "course_outcomes")
@Entity
@NoArgsConstructor
@Setter
@Getter
@IdClass(CourseOutcomeId.class)
public class CourseOutcome {

	@Id
	private String course_code;
	
	@Id
	private String co_id;
	
	private String description;
	
}
