package com.cocopo.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "courses")
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class Course {

	@Id
	private String course_code;
	
	private String course_name;
	private String branch;
	
}
