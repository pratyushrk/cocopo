package com.cocopo.models;

import com.cocopo.ids.MappingId;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "mappings")
@Entity
@NoArgsConstructor
@Setter
@Getter
@IdClass(MappingId.class)
public class Mappings {

	@Id
	private String course_code;	
	
	@Id
	private String co_id;
	
	@Id
	private String po_id;
	
	private int strength;
	
}
