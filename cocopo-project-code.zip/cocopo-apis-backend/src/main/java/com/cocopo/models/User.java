package com.cocopo.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "users")
@Entity
@NoArgsConstructor
@Getter
@Setter
public class User {

	// username is needed as a faculty/user can have multiple accounts/roles so their fullname and email won't be unique
	@Id
	private String username;
	
	private String fullname;
	private String email_id;
	private String password;
	private String role;
	
}
