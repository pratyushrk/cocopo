package com.cocopo.models;

import com.cocopo.ids.OptimizedCoId;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "optimized_co")
@Entity
@NoArgsConstructor
@Getter
@Setter
@IdClass(OptimizedCoId.class)
public class OptimizedCO {

	@Id
	private String co_id;
	
	@Id
	private int optimized_id;
	
	private String description;
	private String status;
	
}
