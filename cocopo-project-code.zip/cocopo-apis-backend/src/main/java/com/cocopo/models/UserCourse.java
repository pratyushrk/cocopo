package com.cocopo.models;

import com.cocopo.ids.UserCourseId;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "user_courses")
@Entity
@NoArgsConstructor
@Getter
@Setter
@IdClass(UserCourseId.class)
public class UserCourse {

	@Id
	private String assigned_faculty;
	
	@Id
	private String course_code;
	
}
