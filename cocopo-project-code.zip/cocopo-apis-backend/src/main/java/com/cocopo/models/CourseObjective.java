package com.cocopo.models;

import com.cocopo.ids.CourseObjectiveId;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "course_objectives")
@Entity
@NoArgsConstructor
@Setter
@Getter
@IdClass(CourseObjectiveId.class)
public class CourseObjective {

	@Id
	private String course_code;
	
	@Id
	private String cobj_id;
	
	private String description;
	
}
