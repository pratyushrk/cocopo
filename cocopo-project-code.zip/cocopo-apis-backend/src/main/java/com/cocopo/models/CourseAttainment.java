package com.cocopo.models;

import com.cocopo.ids.CourseAttainmentId;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "course_attainment")
@Entity
@NoArgsConstructor
@Setter
@Getter
@IdClass(CourseAttainmentId.class)
public class CourseAttainment {

	@Id
	private int year;
	
	@Id
	private String course_code;
	
	@Id
	private String co_id;
	
	private float course_attainment;
	
}
