package com.cocopo.models;

import com.cocopo.ids.ProgramAttainmentId;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "program_attainment")
@Entity
@NoArgsConstructor
@Setter
@Getter
@IdClass(ProgramAttainmentId.class)
public class ProgramAttainment {

	@Id
	private int year;
	
	@Id
	private String co_id;
	
	@Id
	private String po_id;
	
	@Id
	private String course_code;
	
	private float program_attainment;
	
}
