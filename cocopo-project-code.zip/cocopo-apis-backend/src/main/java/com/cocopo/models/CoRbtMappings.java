package com.cocopo.models;

import com.cocopo.ids.CoRbtMappingId;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "co_rbt_mappings")
@Entity
@NoArgsConstructor
@Getter
@Setter
@IdClass(CoRbtMappingId.class)
public class CoRbtMappings {

	@Id
	private String course_code;
	
	@Id
	private String co_id;
	
	@Id
	private String rbt_id;
}
