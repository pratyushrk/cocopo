package com.cocopo.ids;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ProgramAttainmentId implements Serializable {

	public ProgramAttainmentId(){
		
	}
	
	public ProgramAttainmentId(int currentYear, String course_code2, String coId, String poId) {
		this.year = currentYear;
		this.course_code = course_code2;
		this.co_id = coId;
		this.po_id = poId;
	}
	
	private int year;
	private String co_id;
	private String po_id;
	private String course_code;
	
}

