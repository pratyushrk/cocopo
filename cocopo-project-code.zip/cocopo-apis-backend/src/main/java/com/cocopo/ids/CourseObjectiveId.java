package com.cocopo.ids;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CourseObjectiveId implements Serializable {

	private String course_code;
	private String cobj_id;
	
	public CourseObjectiveId() {
		
	}
	
	public CourseObjectiveId(String course_code2, String cobj_id2) {
		this.course_code = course_code2;
		this.cobj_id = cobj_id2;
	}
}
