package com.cocopo.ids;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserCourseId implements Serializable {

	private String assigned_faculty;
	private String course_code;
	
	public UserCourseId() {
		// TODO Auto-generated constructor stub
	}
	
	public UserCourseId(String assigned_faculty2, String course_code2){
		this.assigned_faculty = assigned_faculty2;
		this.course_code = course_code2;
	}
}

