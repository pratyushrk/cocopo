package com.cocopo.ids;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CourseAttainmentId implements Serializable {

	private int year;
	private String course_code;
	private String co_id;
	
	public CourseAttainmentId() {
		
	}
	
	public CourseAttainmentId(int year2,  String course_code2, String co_id2) {
		this.year = year2;
		this.course_code = course_code2;
		this.co_id = co_id2;
	}
	
}
