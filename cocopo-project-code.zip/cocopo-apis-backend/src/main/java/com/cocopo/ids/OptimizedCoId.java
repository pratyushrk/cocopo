package com.cocopo.ids;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OptimizedCoId implements Serializable {

	private String co_id;
	private int optimized_id;
	
	public OptimizedCoId() {
		
	}
	
	public OptimizedCoId(String co_id2, int optimized_id2){
		this.co_id = co_id2;
		this.optimized_id = optimized_id2;
	}
}
