package com.cocopo.ids;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MappingId implements Serializable {

	private String course_code;	
	private String co_id;
	private String po_id;
	
	public MappingId() {
		
	}
	
	public MappingId(String course_code2, String co_id2, String po_id2) {
		this.course_code = course_code2;
		this.co_id = co_id2;
		this.po_id = po_id2;
	}
}

