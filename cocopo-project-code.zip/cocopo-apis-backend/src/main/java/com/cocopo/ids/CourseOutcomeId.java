package com.cocopo.ids;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CourseOutcomeId implements Serializable {

	private String course_code;
	private String co_id;
	
	public CourseOutcomeId() {
		
	}
	
	public CourseOutcomeId(String course_code2, String co_id2) {
		this.course_code = course_code2;
		this.co_id = co_id2;
	}
}

