package com.cocopo.ids;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CoRbtMappingId implements Serializable {

	private String course_code;
	private String co_id;
	private String rbt_id;
	
	public CoRbtMappingId() {
		
	}
	
	public CoRbtMappingId(String course_code2, String co_id2, String rbt_id2) {
		this.course_code = course_code2;
		this.co_id = co_id2;
		this.rbt_id = rbt_id2;
	}
}

