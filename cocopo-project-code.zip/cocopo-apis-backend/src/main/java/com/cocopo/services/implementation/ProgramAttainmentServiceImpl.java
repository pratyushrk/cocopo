package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.models.*;
import com.cocopo.repositories.*;
import com.cocopo.payloads.ProgramAttainmentDTO;
import com.cocopo.services.ProgramAttainmentServices;

@Service
public class ProgramAttainmentServiceImpl implements ProgramAttainmentServices {
	@Autowired
	private ProgramAttainmentRepo pAttainmentRepo;
	
	@Override
	public ProgramAttainmentDTO addProgramAttainment(ProgramAttainmentDTO pAttainmentDTO) {
		ProgramAttainment pAttainment = this.dtoToPAttainment(pAttainmentDTO);
		ProgramAttainment saveAttainment = this.pAttainmentRepo.save(pAttainment);
		return this.pAttainmentToDto(saveAttainment);
	}

	@Override
	public ProgramAttainmentDTO updateProgramAttainment(ProgramAttainmentDTO pAttainmentDTO, int year, String co_id, String po_id, String course_code) {
		ProgramAttainment pAttainment = this.pAttainmentRepo.findByPAttainment(year, co_id, po_id, course_code);
		
		this.pAttainmentRepo.delete(pAttainment);
		
		ProgramAttainmentDTO updatedAttainment = addProgramAttainment(pAttainmentDTO);
		return updatedAttainment;
	}

	@Override
	public ProgramAttainmentDTO getByProgramAttainment(int year, String co_id, String po_id, String course_code) {
		ProgramAttainment pAttainment = this.pAttainmentRepo.findByPAttainment(year, co_id, po_id, course_code);
		return this.pAttainmentToDto(pAttainment);
	}
	
	@Override
	public List<ProgramAttainmentDTO> getProgramAttainmentByCourseCode(String course_code) {
		List<ProgramAttainment> pAttainments = this.pAttainmentRepo.findPAttainmentByCode(course_code);
		
		List<ProgramAttainmentDTO> pAttainmentDTOs = pAttainments.stream().map(this::pAttainmentToDto).collect(Collectors.toList());
		return pAttainmentDTOs;
	}

	@Override
	public List<ProgramAttainmentDTO> getProgramAttainmentByYear(int year) {
		List<ProgramAttainment> pAttainments = this.pAttainmentRepo.findPAttainmentByYear(year);
		
		List<ProgramAttainmentDTO> pAttainmentDTOs = pAttainments.stream().map(this::pAttainmentToDto).collect(Collectors.toList());
		return pAttainmentDTOs;
	}

	@Override
	public void deleteAllProgramAttainment(String course_code) {
		List<ProgramAttainment> pAttainments = this.pAttainmentRepo.findPAttainmentByCode(course_code);
		pAttainments.forEach(this.pAttainmentRepo::delete);		
	}
	
	ProgramAttainment dtoToPAttainment(ProgramAttainmentDTO pAttainmentDTO) {
		ProgramAttainment pAttainment = new ProgramAttainment();
		
		pAttainment.setYear(pAttainmentDTO.getYear());
		pAttainment.setCourse_code(pAttainmentDTO.getCourse_code());
		pAttainment.setCo_id(pAttainmentDTO.getCo_id());
		pAttainment.setPo_id(pAttainmentDTO.getPo_id());
		pAttainment.setProgram_attainment(pAttainmentDTO.getProgram_attainment());
		
		return pAttainment;
	}
	
	ProgramAttainmentDTO pAttainmentToDto(ProgramAttainment pAttainment) {
		ProgramAttainmentDTO pAttainmentDTO = new ProgramAttainmentDTO();
		
		pAttainmentDTO.setYear(pAttainment.getYear());
		pAttainmentDTO.setCourse_code(pAttainment.getCourse_code());
		pAttainmentDTO.setCo_id(pAttainment.getCo_id());
		pAttainmentDTO.setPo_id(pAttainment.getPo_id());
		pAttainmentDTO.setProgram_attainment(pAttainment.getProgram_attainment());
		
		return pAttainmentDTO; 
	}
	
}
