package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.exceptions.*;
import com.cocopo.repositories.*;
import com.cocopo.models.*;
import com.cocopo.payloads.CourseDTO;
import com.cocopo.services.CourseServices;

@Service
public class CourseServiceImpl implements CourseServices {
	@Autowired
	private CourseRepo courseRepo;

	@Override
	public CourseDTO addCourse(CourseDTO courseDto) {
		Course course = this.dtoToCourse(courseDto);
		Course savedCourse = this.courseRepo.save(course);
		return this.courseToDto(savedCourse);
	}

	@Override
	public CourseDTO updateCourse(CourseDTO courseDto, String course_code) {
		// similarly, Course has only one primary key
		Course course = this.courseRepo.findExactCourseByCode(course_code);
		
		deleteCourse(this.courseToDto(course));
		
		CourseDTO updatedCourse = addCourse(courseDto);
		return updatedCourse;
	}

	@SuppressWarnings("null")
	@Override
	public List<CourseDTO> getCourseByCodeList(List<String> codeList) {
		List<CourseDTO> courseDTOs = null;
		for(String course_code : codeList) {
			Course course = this.courseRepo.findExactCourseByCode(course_code);
			courseDTOs.add(this.courseToDto(course));
		}
		return courseDTOs;	
	}

		
	
	@Override
	public List<CourseDTO> getCourseByBranch(String branch) {
		List<Course> courses = this.courseRepo.findCourseByBranch(branch);
		
		List<CourseDTO> courseDtos = courses.stream()
				.map(this::courseToDto)
				.collect(Collectors.toList());
		
		return courseDtos;
	}

	@Override
	public List<CourseDTO> getCourseByCode(String course_code) {
		List<Course> courses = this.courseRepo.findCourseByCode(course_code);
		
		List<CourseDTO> courseDtos = courses.stream()
				.map(this::courseToDto)
				.collect(Collectors.toList());
		
		if (courses.isEmpty()) {
			System.out.printf("No course found with the course code ", course_code);
			return null;
		} else {
		    return courseDtos;
		}
	}

	@Override
	public List<CourseDTO> getCourseByName(String course_name) {
		List<Course> courses = this.courseRepo.findCoursesByName(course_name);
		
		List<CourseDTO> courseDtos = courses.stream()
				.map(this::courseToDto)
				.collect(Collectors.toList());
		
		if (courses.isEmpty()) {
			System.out.printf("No course found with the course name ", course_name);
			return null;
		} else {
		    return courseDtos;
		}
	}

	@Override
	public List<CourseDTO> getAllCourses() {
		List<Course> courses = this.courseRepo.findAll();
		
		List<CourseDTO> courseDtos = courses.stream()
				.map(this::courseToDto)
				.collect(Collectors.toList());
	    return courseDtos;

	}

	@Override
	public void deleteCourse(CourseDTO courseDTO) {
		Course course = this.courseRepo.findById(courseDTO.getCourse_code()).orElseThrow(()-> new ResourceNotFoundException("Course", "course code", courseDTO.getCourse_code()));;
		this.courseRepo.delete(course);

	}
	
	private Course dtoToCourse(CourseDTO courseDto) {
		Course course = new Course();
		
		course.setCourse_code(courseDto.getCourse_code());
		course.setCourse_name(courseDto.getCourse_name());
		course.setBranch(courseDto.getBranch());
		
		return course;
	}
	
	private CourseDTO courseToDto(Course course) {
		CourseDTO courseDto = new CourseDTO();
		
		courseDto.setCourse_code(course.getCourse_code());
		courseDto.setCourse_name(course.getCourse_name());
		courseDto.setBranch(course.getBranch());
		
		return courseDto;
	}

}
