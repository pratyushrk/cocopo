package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.UserCourseDTO;

public interface UserCourseServices {

	UserCourseDTO addUserCourse(UserCourseDTO uCourseDTO);
	UserCourseDTO updateUserCourse(UserCourseDTO uCourseDTO, String assigned_faculty, String course_code);
	List<UserCourseDTO> getUserByCourse(String course_code);	// list of faculties assigned to a course
	List<UserCourseDTO> getAllUserCourses();
	void deleteUserCourse(UserCourseDTO uCourseDTO);
	List<UserCourseDTO> getUserById(String assigned_faculty);
	
}
