package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.models.*;
import com.cocopo.repositories.*;
import com.cocopo.payloads.CourseObjectiveDTO;
import com.cocopo.services.CourseObjectiveServices;

@Service
public class CourseObjectiveServiceImpl implements CourseObjectiveServices {
	@Autowired
	private CourseObjectiveRepo cObjectiveRepo;

	@Override
	public CourseObjectiveDTO addCourseObjective(CourseObjectiveDTO cObjectiveDTO) {
		CourseObjective cObjective = this.dtoToCObjective(cObjectiveDTO);
		CourseObjective savedObjective = this.cObjectiveRepo.save(cObjective);
		return this.cObjectiveToDto(savedObjective);
	}

	@Override
	public CourseObjectiveDTO updateCourseObjective(CourseObjectiveDTO cObjectiveDTO, String cobj_id, String course_code) {
		CourseObjective cObjective = this.cObjectiveRepo.findByObjective(course_code, cobj_id);
				
		this.cObjectiveRepo.delete(cObjective);
		
		CourseObjectiveDTO updatedObjective = addCourseObjective(cObjectiveDTO);
		return updatedObjective;
	}

	@Override
	public CourseObjectiveDTO getExactCourseObjectiveByCourseCode(String course_code, String cobj_id) {
		CourseObjective cObjective = this.cObjectiveRepo.findByObjective(course_code, cobj_id);
		return this.cObjectiveToDto(cObjective);
	}
	
	@Override
	public List<CourseObjectiveDTO> getCourseObjectiveByCourseCode(String course_code) {
		List<CourseObjective> cObjectives = this.cObjectiveRepo.findCObjectiveByCode(course_code);
		
		List<CourseObjectiveDTO> cObjectiveDTOs = cObjectives.stream().map(this::cObjectiveToDto).collect(Collectors.toList());
		return cObjectiveDTOs;
	}
	
	@Override
	public void deleteAllCourseObjective(String course_code) {
		List<CourseObjective> cObjectives = this.cObjectiveRepo.findCObjectiveByCode(course_code);
		cObjectives.forEach(this.cObjectiveRepo::delete);
	}

	private CourseObjectiveDTO cObjectiveToDto(CourseObjective cObjective) {
		CourseObjectiveDTO cObjectiveDTO = new CourseObjectiveDTO();
		
		cObjectiveDTO.setCourse_code(cObjective.getCourse_code());
		cObjectiveDTO.setCobj_id(cObjective.getCobj_id());
		cObjectiveDTO.setDescription(cObjective.getDescription());
		
		return cObjectiveDTO;
	}

	private CourseObjective dtoToCObjective(CourseObjectiveDTO cObjectiveDTO) {
		CourseObjective cObjective = new CourseObjective();
		
		cObjective.setCourse_code(cObjectiveDTO.getCourse_code());
		cObjective.setCobj_id(cObjectiveDTO.getCobj_id());
		cObjective.setDescription(cObjectiveDTO.getDescription());
		
		return cObjective;
	}
}

