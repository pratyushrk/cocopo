package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.repositories.*;
import com.cocopo.models.*;
import com.cocopo.payloads.UserDTO;
import com.cocopo.services.UserServices;

@Service
public class UserServiceImpl implements UserServices {
	@Autowired
	private UserRepo userRepo;
	
	@Override
	public UserDTO addUser(UserDTO userDto) {
		// need to convert data transfer object to model/entity
		User user = this.dtoToUser(userDto);
		// save it to the repository
		User savedUser = this.userRepo.save(user);
		// need to convert back to DTO to transfer data
		return this.userToDto(savedUser);
	}

	@Override
	public UserDTO updateUser(UserDTO userDto, String username) {
		
		deleteUser(username);
		UserDTO updatedUser = addUser(userDto);
		return updatedUser;
	} 

	@Override
	public List<UserDTO> getUserById(String username) {
		List<User> users = this.userRepo.findUserByUsername(username);
		
		List<UserDTO> userDTOs = users.stream().map(this::userToDto).collect(Collectors.toList());
		return userDTOs;
		
	}
	
	@Override
	public List<UserDTO> getUserByName(String fullname) {
		List<User> users = this.userRepo.findUserByFullname(fullname);
		// get the list, then take action based on what it returned (null or not) 
		
		// applies the userToDto method to each element in the stream.
		List<UserDTO> userDtos = users.stream()
	            .map(this::userToDto)
	            .collect(Collectors.toList());
		
		if (users.isEmpty()) {
		    // No user found with the given fullname
			System.out.printf("No user found with the name ", fullname);
			return null;
		} else {
		    // single or multiple users found
		    return userDtos;
		}
	}

	@Override
	public List<UserDTO> getAllUsers() {
		List<User> users = this.userRepo.findAll();
		
		List<UserDTO> userDtos = users.stream().map(this::userToDto).collect(Collectors.toList());		
		return userDtos;
	}

	@Override
	public void deleteUser(String username) {
		User user = this.userRepo.findExactByUsername(username);
		this.userRepo.delete(user);
	}
	
	// UserDTO used *only* to transfer data; After data transfer, you need to change the type of the data back to User when you are interacting with database (CRUD operations); Provides separation of concern and security;
	// we can use Model Mapper for this instead, but for now...
	private User dtoToUser(UserDTO userDto) {		
		User user = new User();
		user.setUsername(userDto.getUsername());
		user.setFullname(userDto.getFullname());
		user.setEmail_id(userDto.getEmail_id());
		user.setPassword(userDto.getPassword());
		user.setRole(userDto.getRole());
		return user;		
	}
	
	private UserDTO userToDto(User user) {		
		UserDTO userDto = new UserDTO();
		userDto.setUsername(user.getUsername());
		userDto.setFullname(user.getFullname());
		userDto.setEmail_id(user.getEmail_id());
		userDto.setPassword(user.getPassword());
		userDto.setRole(user.getRole());
		return userDto;		
	}

}











