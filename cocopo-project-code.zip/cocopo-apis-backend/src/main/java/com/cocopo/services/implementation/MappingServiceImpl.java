package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.models.*;
import com.cocopo.repositories.*;
import com.cocopo.payloads.MappingsDTO;
import com.cocopo.services.MappingServices;

@Service
public class MappingServiceImpl implements MappingServices {
	@Autowired
	private MappingsRepo mappingsRepo;
	
	@Override
	public MappingsDTO addMapping(MappingsDTO mappingDto) {
		// Don't create mapping if strength is 0
		if (mappingDto.getStrength() == 0) {
			return null;
		}else {
			Mappings mapping = this.dtoToMapping(mappingDto);
			Mappings savedMapping = this.mappingsRepo.save(mapping);
			return this.mappingToDto(savedMapping);
		}
	}

	@Override
	public MappingsDTO updateMapping(MappingsDTO mappingDto, String course_code, String co_id, String po_id) {
		// this function needs to be called in loop
		// FINAL APPROACH TO BE DECIDED after connecting to forntend
		
		// Check if strength is null/zero, if yes, delete the mapping
	    if (mappingDto.getStrength() == 0) {
	        deleteMapping(mappingDto);
	        return null;
	    }
   
	    // we can't use findById as we have a joint primary key and hence we'll need to define our own
	    Mappings mapping = this.mappingsRepo.findByMapping(course_code, co_id, po_id);

	    // If mapping is null, add a new mapping
	    if (mapping == null) {
	        addMapping(mappingDto);
	        return null;
	    } else {
	        // Update the strength if mapping is not null
	        mapping.setStrength(mappingDto.getStrength());
	        Mappings updatedMapping = this.mappingsRepo.save(mapping);
	        return this.mappingToDto(updatedMapping); 
	    }
	}

	@Override
	public List<MappingsDTO> getMappingsByCourseCode(String course_code) {
		List<Mappings> mappings = this.mappingsRepo.findMappingByCode(course_code);
		
		List<MappingsDTO> mappingsDtos = mappings.stream().map(this::mappingToDto).collect(Collectors.toList());
		
		if (mappings.isEmpty()) {
			System.out.printf("No course found with the course code ", course_code);
			return null;
		} else {
		    return mappingsDtos;
		}
		
	}

	@Override
	public void deleteMapping(MappingsDTO mappingDto) {
		Mappings mapping = this.mappingsRepo.findByMapping(mappingDto.getCourse_code(), mappingDto.getCo_id(), mappingDto.getPo_id());
		this.mappingsRepo.delete(mapping);		
	}
	
	@Override
	public void deleteAllMapping(String course_code) {
		//delete all mappings of a course
		List<Mappings> mappings = this.mappingsRepo.findMappingByCode(course_code);
		
		mappings.stream().forEach(this.mappingsRepo::delete);
	}
	
	private MappingsDTO mappingToDto(Mappings mapping) {
		MappingsDTO mappingDto = new MappingsDTO();			

		mappingDto.setCourse_code(mapping.getCourse_code());
		mappingDto.setCo_id(mapping.getCo_id());
		mappingDto.setPo_id(mapping.getPo_id());
		mappingDto.setStrength(mapping.getStrength());
		
		return mappingDto;
	}
	
	private Mappings dtoToMapping(MappingsDTO mappingDto) {
		Mappings mapping = new Mappings();
		
		mapping.setCourse_code(mappingDto.getCourse_code());
		mapping.setCo_id(mappingDto.getCo_id());
		mapping.setPo_id(mappingDto.getPo_id());
		mapping.setStrength(mappingDto.getStrength());
		
		return mapping;
	}


}
