package com.cocopo.services;

import java.io.File;

public interface StudentMarkServices {

	// TO BE DECIDED
	void calculateAllAttainments(File filename, String course_code);

	File getModifiedFile();
	
}
