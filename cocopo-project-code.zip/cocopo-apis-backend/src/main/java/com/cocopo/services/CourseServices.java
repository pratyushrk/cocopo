package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.CourseDTO;

public interface CourseServices {

	CourseDTO addCourse(CourseDTO courseDto);
	CourseDTO updateCourse(CourseDTO courseDto, String course_code);	//new data + primary key
	List<CourseDTO> getCourseByBranch(String branch);
	List<CourseDTO> getCourseByCode(String course_code);
	List<CourseDTO> getCourseByName(String course_name);
	List<CourseDTO> getAllCourses();
	void deleteCourse(CourseDTO courseDto);
	List<CourseDTO> getCourseByCodeList(List<String> codeList);
	
}
