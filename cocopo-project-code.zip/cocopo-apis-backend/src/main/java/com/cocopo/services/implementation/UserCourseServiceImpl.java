package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.models.*;
import com.cocopo.repositories.*;
import com.cocopo.payloads.UserCourseDTO;
import com.cocopo.services.UserCourseServices;

@Service
public class UserCourseServiceImpl implements UserCourseServices {
	@Autowired
	private UserCourseRepo uCourseRepo;
	
	@Override
	public UserCourseDTO addUserCourse(UserCourseDTO userCourseDTO) {
		UserCourse userCourse = this.dtoToUCourse(userCourseDTO);
		UserCourse savedUserCourse = this.uCourseRepo.save(userCourse);
		return this.uCourseToDto(savedUserCourse);
	}

	@Override
	public UserCourseDTO updateUserCourse(UserCourseDTO uCourseDTO, String assigned_faculty, String course_code) {
		UserCourse userCourse = this.uCourseRepo.findUserCourse(assigned_faculty, course_code);
		
		deleteUserCourse(this.uCourseToDto(userCourse));
		UserCourseDTO userCourseDTO = addUserCourse(uCourseDTO);
		
		return userCourseDTO;
	}

	@Override
	public List<UserCourseDTO> getUserByCourse(String course_code) {
		List<UserCourse> userCourses = this.uCourseRepo.findUserByCourse(course_code);
		List<UserCourseDTO> userCourseDTOs = userCourses.stream().map(this::uCourseToDto).collect(Collectors.toList());
		return userCourseDTOs;
	}
	
	@Override
	public List<UserCourseDTO> getUserById(String assigned_faculty) {
		List<UserCourse> userCourses = this.uCourseRepo.findUserById(assigned_faculty);
		List<UserCourseDTO> userCourseDTOs = userCourses.stream().map(this::uCourseToDto).collect(Collectors.toList());
		return userCourseDTOs;
	}

	@Override
	public List<UserCourseDTO> getAllUserCourses() {
		List<UserCourse> userCourses = this.uCourseRepo.findAll();
		List<UserCourseDTO> userCourseDTOs = userCourses.stream().map(this::uCourseToDto).collect(Collectors.toList());
		return userCourseDTOs;
	}

	@Override
	public void deleteUserCourse(UserCourseDTO uCourseDTO) {
		UserCourse userCourse = this.uCourseRepo.findUserCourse(uCourseDTO.getAssigned_faculty(), uCourseDTO.getCourse_code());
		this.uCourseRepo.delete(userCourse);
	}

	private UserCourse dtoToUCourse(UserCourseDTO userCourseDTO) {
		UserCourse userCourse = new UserCourse();
		
		userCourse.setAssigned_faculty(userCourseDTO.getAssigned_faculty());
		userCourse.setCourse_code(userCourseDTO.getCourse_code());
		
		return userCourse;
	}

	private UserCourseDTO uCourseToDto(UserCourse userCourse) {
		UserCourseDTO userCourseDTO = new UserCourseDTO();
		
		userCourseDTO.setAssigned_faculty(userCourse.getAssigned_faculty());
		userCourseDTO.setCourse_code(userCourse.getCourse_code());
		
		return userCourseDTO;
	}
	
}
