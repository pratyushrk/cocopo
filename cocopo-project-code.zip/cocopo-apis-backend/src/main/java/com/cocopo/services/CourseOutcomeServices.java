package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.CourseOutcomeDTO;

public interface CourseOutcomeServices {

	CourseOutcomeDTO addCourseOutcome(CourseOutcomeDTO coDto);
	CourseOutcomeDTO updateCourseOutcome(CourseOutcomeDTO coDto, String co_id, String course_code);
	List<CourseOutcomeDTO> getCourseOutcomeByCourseCode(String course_code);
	List<String> getAllCourseCodes();
	void deleteAllCourseOutcome(String course_code);
	CourseOutcomeDTO getExactCourseOutcomeByCourseCode(String course_code, String co_id);
	
}
