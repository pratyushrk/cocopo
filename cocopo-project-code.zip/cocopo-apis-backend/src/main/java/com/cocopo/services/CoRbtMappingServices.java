package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.CoRbtMappingsDTO;

public interface CoRbtMappingServices {

	CoRbtMappingsDTO addRbtMappings(CoRbtMappingsDTO rbtMappingsDTO);
	List<CoRbtMappingsDTO> updateRbtMappings(String course_code, String co_id, List<String> rbtList);
	List<String> getRbtMappingsByCode(String course_code, String co_id);	// only the mappings that have been stored, for unchecked ones decide what to do from where you call, not here. to be memory efficient 
	void deleteRbtMapping(CoRbtMappingsDTO rbtMappingsDTO);	// delete mapping when it is unchecked (or not in the checked mappings' list)
	void deleteAllRbtMappings(String course_code);	// if course gets deleted, delete mappings too.
	
}
