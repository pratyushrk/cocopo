package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.OptimizedCoDTO;

public interface OptimizedCoServices {

	OptimizedCoDTO addOptimizedCO(OptimizedCoDTO coDTO);
	OptimizedCoDTO updateStatus(String course_code, String co_id, int optimized_id);
	OptimizedCoDTO getSelectedOptimizedCO(String co_id);	// fetches the selected optimized version for given co_id
	List<OptimizedCoDTO> getAllSelectedOptimizedCOs();	// fetches all selected optimized versions for a course
	void deleteAllOptimizedCo();
	List<OptimizedCoDTO> getOptimizedCOByCode(String co_id);
	void RunJupyterNotebook(List<String> CoList);
		
}
