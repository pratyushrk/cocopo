package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.models.*;
import com.cocopo.repositories.*;
import com.cocopo.payloads.CourseOutcomeDTO;
import com.cocopo.services.CourseOutcomeServices;

@Service
public class CourseOutcomeServiceIpml implements CourseOutcomeServices {
	@Autowired
	private CourseOutcomeRepo cOutcomeRepo;
	
	@Override
	public CourseOutcomeDTO addCourseOutcome(CourseOutcomeDTO cOutcomeDTO) {
		CourseOutcome cOutcome = this.dtoToCOutcome(cOutcomeDTO);
		CourseOutcome savedOutcome = this.cOutcomeRepo.save(cOutcome);
		return this.cOutcomeToDto(savedOutcome);
	}

	@Override
	public CourseOutcomeDTO updateCourseOutcome(CourseOutcomeDTO cOutcomeDTO, String co_id, String course_code) {
		CourseOutcome cOutcome = this.cOutcomeRepo.findByOutcome(course_code, co_id);
		
		this.cOutcomeRepo.delete(cOutcome);
		CourseOutcomeDTO updatedOutcomeDTO = addCourseOutcome(cOutcomeDTO);
		
		return updatedOutcomeDTO;
	}

	@Override
	public CourseOutcomeDTO getExactCourseOutcomeByCourseCode(String course_code, String co_id) {
		CourseOutcome cOutcome = this.cOutcomeRepo.findByOutcome(course_code, co_id);
		return this.cOutcomeToDto(cOutcome);
	}
	
	@Override
	public List<CourseOutcomeDTO> getCourseOutcomeByCourseCode(String course_code) {
		List<CourseOutcome> cOutcomes = this.cOutcomeRepo.findOutcomeByCode(course_code);
		
		List<CourseOutcomeDTO> cOutcomeDTOs = cOutcomes.stream().map(this::cOutcomeToDto).collect(Collectors.toList());		
		return cOutcomeDTOs;
	}
	
	@Override
	public List<String> getAllCourseCodes() {
		return this.cOutcomeRepo.findAllCourseCodes();
		
	}
	
	@Override
	public void deleteAllCourseOutcome(String course_code) {
		List<CourseOutcome> cOutcomes = this.cOutcomeRepo.findOutcomeByCode(course_code);
		cOutcomes.forEach(this.cOutcomeRepo::delete);
		
	}

	private CourseOutcome dtoToCOutcome(CourseOutcomeDTO cOutcomeDTO) {
		CourseOutcome cOutcome = new CourseOutcome();
		
		cOutcome.setCourse_code(cOutcomeDTO.getCourse_code());
		cOutcome.setCo_id(cOutcomeDTO.getCo_id());
		cOutcome.setDescription(cOutcomeDTO.getDescription());
		
		return cOutcome;
	}

	private CourseOutcomeDTO cOutcomeToDto(CourseOutcome cOutcome) {
		CourseOutcomeDTO cOutcomeDTO = new CourseOutcomeDTO();
		
		cOutcomeDTO.setCourse_code(cOutcome.getCourse_code());
		cOutcomeDTO.setCo_id(cOutcome.getCo_id());
		cOutcomeDTO.setDescription(cOutcome.getDescription());
		
		return cOutcomeDTO;
	}
	
}
