package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.models.*;
import com.cocopo.repositories.*;
import com.cocopo.payloads.CourseAttainmentDTO;
import com.cocopo.services.CourseAttainmentServices;

@Service
public class CourseAttainmentServiceImpl implements CourseAttainmentServices {
	@Autowired
	private CourseAttainmentRepo cAttainmentRepo;
	
	@Override
	public CourseAttainmentDTO addCourseAttainment(CourseAttainmentDTO cAttainmentDTO) {
		CourseAttainment cAttainment = this.dtoToCAttainment(cAttainmentDTO);
		CourseAttainment savedAttainment = this.cAttainmentRepo.save(cAttainment);
		return this.CAttainmentToDto(savedAttainment);
		// is it correct? do we need check for null entries?
	}

	@Override
	public CourseAttainmentDTO updateCourseAttainment(CourseAttainmentDTO cAttainmentDTO, int year, String co_id, String course_code) {
        CourseAttainment cAttainment = this.cAttainmentRepo.findByCAttainment(year, co_id, course_code);

        this.cAttainmentRepo.delete(cAttainment);
		
		CourseAttainmentDTO updatedAttainment = addCourseAttainment(cAttainmentDTO);
		return updatedAttainment;
	}

	@Override
	public CourseAttainmentDTO getByCourseAttainment(int year, String co_id, String course_code) {
		CourseAttainment cAttainment = this.cAttainmentRepo.findByCAttainment(year, co_id, course_code);
		return this.CAttainmentToDto(cAttainment);
	}
	
	@Override
	public List<CourseAttainmentDTO> getCourseAttainmentByCourseCode(String course_code) {
		List<CourseAttainment> cAttainments = this.cAttainmentRepo.findCAttainmentByCode(course_code);
		
		List<CourseAttainmentDTO> cAttainmentDTOs = cAttainments.stream().map(this::CAttainmentToDto).collect(Collectors.toList());
		return cAttainmentDTOs;
	}

	@Override
	public List<CourseAttainmentDTO> getCourseAttainmentByYear(int year) {
		List<CourseAttainment> cAttainments = this.cAttainmentRepo.findCAttainmentByYear(year);
		
		List<CourseAttainmentDTO> cAttainmentDTOs = cAttainments.stream().map(this::CAttainmentToDto).collect(Collectors.toList());
		return cAttainmentDTOs;
	}

	@Override
	public void deleteAllCourseAttainment(String course_code) {
		List<CourseAttainment> cAttainments = this.cAttainmentRepo.findCAttainmentByCode(course_code);
		cAttainments.forEach(this.cAttainmentRepo::delete);
	}
	
	CourseAttainment dtoToCAttainment(CourseAttainmentDTO cAttainmentDTO) {
		CourseAttainment cAttainment = new CourseAttainment();
		
		cAttainment.setYear(cAttainmentDTO.getYear());
		cAttainment.setCourse_code(cAttainmentDTO.getCourse_code());
		cAttainment.setCo_id(cAttainmentDTO.getCo_id());
		cAttainment.setCourse_attainment(cAttainmentDTO.getCourse_attainment());
		
		return cAttainment;
	}

	CourseAttainmentDTO CAttainmentToDto(CourseAttainment cAttainment) {
		CourseAttainmentDTO cAttainmentDTO = new CourseAttainmentDTO();
		
		cAttainmentDTO.setYear(cAttainment.getYear());
		cAttainmentDTO.setCourse_code(cAttainment.getCourse_code());
		cAttainmentDTO.setCo_id(cAttainment.getCo_id());
		cAttainmentDTO.setCourse_attainment(cAttainment.getCourse_attainment());
		
		return cAttainmentDTO;
	}
		
}
