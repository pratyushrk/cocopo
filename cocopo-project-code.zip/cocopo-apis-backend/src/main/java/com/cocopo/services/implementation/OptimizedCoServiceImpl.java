package com.cocopo.services.implementation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.models.*;
import com.cocopo.payloads.CourseObjectiveDTO;
import com.cocopo.payloads.CourseOutcomeDTO;
import com.cocopo.payloads.OptimizedCoDTO;
import com.cocopo.repositories.*;
import com.cocopo.services.CourseObjectiveServices;
import com.cocopo.services.CourseOutcomeServices;
import com.cocopo.services.OptimizedCoServices;

@Service
public class OptimizedCoServiceImpl implements OptimizedCoServices {
	@Autowired
	private OptimizedCoRepo coRepo;
	
	@Autowired
	private CourseOutcomeServices cOutcomeServices;
	
	@Autowired
	private CourseObjectiveServices cObjectiveServices;
	
	@Override
	public OptimizedCoDTO addOptimizedCO(OptimizedCoDTO coDTO) {
		OptimizedCO co = this.dtoToCo(coDTO);
		OptimizedCO savedCo = this.coRepo.save(co);
		return this.coToDto(savedCo);
	}

	@Override
	public OptimizedCoDTO updateStatus(String course_code, String co_id, int optimized_id) {
	    OptimizedCO selectedCo = this.coRepo.findSelectedOptimizedCO(co_id);

	    if (selectedCo == null) {
	        // go to the next part of the code
	    } else {
	        selectedCo.setStatus("unselected");
	    }

	    OptimizedCO co = this.coRepo.findOptimizedCO(co_id, optimized_id);
	    co.setStatus("selected");

	    OptimizedCO finalSelectedCo = this.coRepo.findSelectedOptimizedCO(co_id);

	    // Check if co_id matches the pattern for Course Outcome or Course Objective
	    if (co_id.matches("^cobj\\d+$")) {
	        // If co_id is in the format "cobj{number}", call updateCourseOutcome
	        CourseOutcomeDTO cOutcomeDTO = this.cOutcomeServices.getExactCourseOutcomeByCourseCode(course_code, co_id);
	        cOutcomeDTO.setDescription(finalSelectedCo.getDescription());
	        this.cOutcomeServices.updateCourseOutcome(cOutcomeDTO, course_code, co_id);
	    } else if (co_id.matches("^co\\d+$")) {
	        // If co_id is in the format "co{number}", call updateCourseObjective
	        CourseObjectiveDTO cObjectiveDTO = this.cObjectiveServices.getExactCourseObjectiveByCourseCode(course_code, co_id);
	        cObjectiveDTO.setDescription(finalSelectedCo.getDescription());
	        this.cObjectiveServices.updateCourseObjective(cObjectiveDTO, course_code, co_id);
	    }

	    return this.coToDto(co);
	}


	@Override
	public OptimizedCoDTO getSelectedOptimizedCO(String co_id) {
		OptimizedCO selectedCo = this.coRepo.findSelectedOptimizedCO(co_id);
		return this.coToDto(selectedCo);
	}

	@Override
	public List<OptimizedCoDTO> getAllSelectedOptimizedCOs() {
		List<OptimizedCO> selectedCo = this.coRepo.findAllSelectedOptimizedCOs();
		
		List<OptimizedCoDTO> selecteCoDTOs = selectedCo.stream().map(this::coToDto).collect(Collectors.toList());
		return selecteCoDTOs;
	}
	
	@Override
	public List<OptimizedCoDTO> getOptimizedCOByCode(String co_id) {
		List<OptimizedCO> selectedCo = this.coRepo.findOptimizedCOByCode(co_id);
		List<OptimizedCoDTO> selecteCoDTOs = selectedCo.stream().map(this::coToDto).collect(Collectors.toList());
		return selecteCoDTOs;
	}

	@Override
	public void deleteAllOptimizedCo() {
		this.coRepo.deleteAll();

	}
	
	@Override
	public void RunJupyterNotebook(List<String> CoList) {
		try {
			String notebookPath = "D:\\Jupyter workspace\\Paraphraser.ipynb";

            // Convert the notebook to a script using nbconvert
            String convertCommand = "D:\\anaconda3\\Scripts\\jupyter.exe";
            String[] convertArguments = {"nbconvert", "--to", "script", notebookPath};
            String[] fullConvertCommand = new String[convertArguments.length + 1];
            fullConvertCommand[0] = convertCommand;
            System.arraycopy(convertArguments, 0, fullConvertCommand, 1, convertArguments.length);

            ProcessBuilder convertProcessBuilder = new ProcessBuilder(fullConvertCommand);
            Process convertProcess = convertProcessBuilder.start();

            // Wait for the conversion process to finish
            convertProcess.waitFor();

            // Run the generated script
            String scriptPath = "D://Jupyter workspace/Paraphraser.py";
            List<String> runCommand = new ArrayList<>();
            runCommand.add("python");
            runCommand.add(scriptPath);
            runCommand.addAll(CoList);  // Add each sentence from CoList as an argument

            ProcessBuilder runProcessBuilder = new ProcessBuilder(runCommand);
            Process runProcess = runProcessBuilder.start();

            // Read output from the process
            BufferedReader reader = new BufferedReader(new InputStreamReader(runProcess.getInputStream()));
            List<String> outputLines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                outputLines.add(line);
            }

            // Wait for the run process to finish
            runProcess.waitFor();
            
            // Process the output lines and add them to the database
            List<OptimizedCO> optimizedCOList = processOutputLines(outputLines);
            List<OptimizedCoDTO> optimizedCOListDTOs = optimizedCOList.stream().map(this::coToDto).collect(Collectors.toList());
            for (OptimizedCoDTO optimizedCO : optimizedCOListDTOs) {
                this.addOptimizedCO(optimizedCO);
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
	}
	
	private List<OptimizedCO> processOutputLines(List<String> outputLines) {
        List<OptimizedCO> optimizedCOList = new ArrayList<>();

        // Assuming each output line corresponds to a description
        int optimizedId = 1;
        int coIdCounter = 1;

        for (String description : outputLines) {
            String coId;
            if (coIdCounter <= 20) {
                coId = "co" + (coIdCounter / 4 + 1);
            } else {
                coId = "cobj" + ((coIdCounter - 20) / 4 + 1);
            }
            
            optimizedId = (coIdCounter - 1) % 4 + 1; // Reset to 1 after every 4 increments

            OptimizedCO optimizedCO = new OptimizedCO();
            
            optimizedCO.setCo_id(coId);
            optimizedCO.setOptimized_id(optimizedId);
            optimizedCO.setDescription(description);
            optimizedCO.setStatus("unselected");
            
            optimizedCOList.add(optimizedCO);

            coIdCounter++;
        }

        return optimizedCOList;
    }

	private OptimizedCO dtoToCo(OptimizedCoDTO coDTO) {
		OptimizedCO co = new OptimizedCO();
		
		co.setCo_id(coDTO.getCo_id());
		co.setOptimized_id(coDTO.getOptimized_id());
		co.setDescription(coDTO.getDescription());
		co.setStatus(coDTO.getStatus());
		
		return co;
	}

	private OptimizedCoDTO coToDto(OptimizedCO co) {
		OptimizedCoDTO coDTO = new OptimizedCoDTO();
		
		coDTO.setCo_id(co.getCo_id());
		coDTO.setOptimized_id(co.getOptimized_id());
		coDTO.setDescription(co.getDescription());
		coDTO.setStatus(co.getStatus());
		
		return coDTO;
	}
	
}
