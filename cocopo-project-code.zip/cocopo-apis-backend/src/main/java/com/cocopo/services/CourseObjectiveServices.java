package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.CourseObjectiveDTO;

public interface CourseObjectiveServices {

	CourseObjectiveDTO addCourseObjective(CourseObjectiveDTO cobjDto);
	CourseObjectiveDTO updateCourseObjective(CourseObjectiveDTO cobjDto, String cobj_id, String course_code);
	List<CourseObjectiveDTO> getCourseObjectiveByCourseCode(String course_code);
	void deleteAllCourseObjective(String course_code);
	CourseObjectiveDTO getExactCourseObjectiveByCourseCode(String course_code, String cobj_id);
	
}
