package com.cocopo.services.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cocopo.models.*;
import com.cocopo.repositories.*;
import com.cocopo.payloads.CoRbtMappingsDTO;
import com.cocopo.services.CoRbtMappingServices;

@Service
public class CoRbtMappingServiceImpl implements CoRbtMappingServices {
	@Autowired
	private CoRbtMappingsRepo rbtMappingsRepo;
	
	@Override
	public CoRbtMappingsDTO addRbtMappings(CoRbtMappingsDTO rbtMappingsDTO) {
		CoRbtMappings rbtMappings = this.dtoToRbt(rbtMappingsDTO);
		CoRbtMappings savedRbtMappings = this.rbtMappingsRepo.save(rbtMappings);
		return this.rbtToDto(savedRbtMappings);
	}

	@Override
	public List<CoRbtMappingsDTO> updateRbtMappings(String course_code, String co_id, List<String> rbtListDTO) {
	    // Get the list of RBT for the given course_code and co_id from the database
	    List<String> rbtList = this.rbtMappingsRepo.findRbtListByCode(course_code, co_id);

	    // Check and update RBT mappings
	    for (String rbt : rbtList) {
	        if (!rbtListDTO.contains(rbt)) {
	            // RBT exists in the database but not in the new list, delete it	        	
	        	CoRbtMappingsDTO rbtMappingsDTO = new CoRbtMappingsDTO();
	        	rbtMappingsDTO.setCourse_code(course_code);
	        	rbtMappingsDTO.setCo_id(co_id);
	        	rbtMappingsDTO.setRbt_id(rbt);
	        	
	            deleteRbtMapping(rbtMappingsDTO);
	        }
	    }

	    for (String rbt_id : rbtListDTO) {
	        if (!rbtList.contains(rbt_id)) {
	            // RBT exists in the new list but not in the database, add it	        	
	        	CoRbtMappingsDTO rbtMappingsDTO = new CoRbtMappingsDTO();
	        	rbtMappingsDTO.setCourse_code(course_code);
	        	rbtMappingsDTO.setCo_id(co_id);
	        	rbtMappingsDTO.setRbt_id(rbt_id);
	        	
	            addRbtMappings(rbtMappingsDTO);
	        }
	    }

	    // Return the updated list of mappings for the given course_code and co_id
	    List<CoRbtMappings> updatedRbtMappings = this.rbtMappingsRepo.findRbtMappingsByCode(course_code, co_id);
	    List<CoRbtMappingsDTO> updatedRbtMappingsDTOs = updatedRbtMappings.stream().map(this::rbtToDto).collect(Collectors.toList());
	    return updatedRbtMappingsDTOs;
	}

	@Override
	public List<String> getRbtMappingsByCode(String course_code, String co_id) {
		List<String> rbtList = this.rbtMappingsRepo.findRbtListByCode(course_code, co_id);
		return rbtList;
	}

	@Override
	public void deleteRbtMapping(CoRbtMappingsDTO rbtMappingsDTO) {
		CoRbtMappings rbtMapping = this.rbtMappingsRepo.findRbtMapping(rbtMappingsDTO.getCourse_code(), rbtMappingsDTO.getCo_id(), rbtMappingsDTO.getRbt_id());
		this.rbtMappingsRepo.delete(rbtMapping);
	}

	@Override
	public void deleteAllRbtMappings(String course_code) {
		List<CoRbtMappings> rbtMappings = this.rbtMappingsRepo.findRbtMappingsByCourse(course_code);
		rbtMappings.forEach(this.rbtMappingsRepo::delete);

	}

	private CoRbtMappings dtoToRbt(CoRbtMappingsDTO rbtMappingsDTO) {
		CoRbtMappings rbtMapping = new CoRbtMappings();
		
		rbtMapping.setCourse_code(rbtMappingsDTO.getCourse_code());
    	rbtMapping.setCo_id(rbtMappingsDTO.getCo_id());
    	rbtMapping.setRbt_id(rbtMappingsDTO.getRbt_id());
		
		return rbtMapping;
	}
	
	private CoRbtMappingsDTO rbtToDto(CoRbtMappings rbtMapping) {
		CoRbtMappingsDTO rbtMappingsDTO = new CoRbtMappingsDTO();
		
		rbtMappingsDTO.setCourse_code(rbtMapping.getCourse_code());
		rbtMappingsDTO.setCo_id(rbtMapping.getCo_id());
		rbtMappingsDTO.setRbt_id(rbtMapping.getRbt_id());
		
		return rbtMappingsDTO;
	}
	
}
