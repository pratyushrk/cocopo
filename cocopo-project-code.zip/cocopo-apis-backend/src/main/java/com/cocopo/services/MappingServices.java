package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.MappingsDTO;

public interface MappingServices {

	MappingsDTO addMapping(MappingsDTO mappingDto);
	MappingsDTO updateMapping(MappingsDTO mappingDto, String course_code, String co_id, String po_id);	// new data + primary keys
	List<MappingsDTO> getMappingsByCourseCode(String course_code);
	void deleteMapping(MappingsDTO mappingsDTO);
	void deleteAllMapping(String course_code);
	
}
