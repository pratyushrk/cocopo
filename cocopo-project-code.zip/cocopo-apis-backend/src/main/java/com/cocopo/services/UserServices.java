package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.UserDTO;

public interface UserServices {

	UserDTO addUser(UserDTO userDto);
	// in updateUser, user contains the new user details via userDto AND username (before change), the primary key of 'users' table 
	UserDTO updateUser(UserDTO userDto, String username);
	List<UserDTO> getUserById(String username);
	List<UserDTO> getUserByName(String fullname);
	List<UserDTO> getAllUsers();
	void deleteUser(String username); 
	
}
