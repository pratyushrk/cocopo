package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.ProgramAttainmentDTO;

public interface ProgramAttainmentServices {

	ProgramAttainmentDTO addProgramAttainment(ProgramAttainmentDTO pAttainmentDTO);
	ProgramAttainmentDTO updateProgramAttainment(ProgramAttainmentDTO pAttainmentDTO, int year, String co_id,String po_id, String course_code);
	// another program to get prog att. by co_id
	ProgramAttainmentDTO getByProgramAttainment(int year, String co_id,String po_id, String course_code);
	List<ProgramAttainmentDTO> getProgramAttainmentByCourseCode(String course_code);
	List<ProgramAttainmentDTO> getProgramAttainmentByYear(int year);
	void deleteAllProgramAttainment(String course_code);
}
