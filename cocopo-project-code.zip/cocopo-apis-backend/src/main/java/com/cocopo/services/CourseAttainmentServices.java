package com.cocopo.services;

import java.util.List;

import com.cocopo.payloads.CourseAttainmentDTO;

public interface CourseAttainmentServices {

	CourseAttainmentDTO addCourseAttainment(CourseAttainmentDTO cAttainmentDTO);
	CourseAttainmentDTO updateCourseAttainment(CourseAttainmentDTO cAttainmentDTO, int year, String co_id, String course_code);
	CourseAttainmentDTO getByCourseAttainment(int year, String co_id, String course_code);
	List<CourseAttainmentDTO> getCourseAttainmentByCourseCode(String course_code);
	List<CourseAttainmentDTO> getCourseAttainmentByYear(int year);	//is it needed at this stage?
	void deleteAllCourseAttainment(String course_code);
	
}
