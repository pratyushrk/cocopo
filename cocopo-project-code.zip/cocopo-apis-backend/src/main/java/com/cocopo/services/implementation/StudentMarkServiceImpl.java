package com.cocopo.services.implementation;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cocopo.payloads.CourseAttainmentDTO;
import com.cocopo.payloads.MappingsDTO;
import com.cocopo.payloads.ProgramAttainmentDTO;
import com.cocopo.services.*;
import com.cocopo.utils.ExcelFormulaPusher;

@Service
public class StudentMarkServiceImpl implements StudentMarkServices {

    @Autowired
    private CourseAttainmentServices cAttainmentServices;

    @Autowired
    private ProgramAttainmentServices pAttainmentServices;

    @Autowired
    private MappingServices mappingServices;
    
    @Autowired
    private ExcelFormulaPusher formulaPusher;
    
    private Workbook modifiedWorkbook;

    @Override
    public void calculateAllAttainments(File filename, String course_code) {
        try {
            String filePath = "D:\\COCOPO-project\\sts-4.20.0.RELEASE\\uploadsToWebsite\\Modified_Formula_template.xlsx";

            Workbook modifiedWorkbook = WorkbookFactory.create(new File(filePath));
            Sheet modifiedFile = modifiedWorkbook.getSheetAt(0);
        	
        	FormulaEvaluator formulaEvaluator = modifiedFile.getWorkbook().getCreationHelper().createFormulaEvaluator();

            List<MappingsDTO> mappingsList = mappingServices.getMappingsByCourseCode(course_code);

            List<CourseAttainmentDTO> courseAttainmentList = cAttainmentServices.getCourseAttainmentByCourseCode(course_code);

            List<ProgramAttainmentDTO> programAttainmentList = pAttainmentServices.getProgramAttainmentByCourseCode(course_code);
            
            // Step 3: Traverse through mappingsList
            for (MappingsDTO mappingsDTO : mappingsList) {
            	
                String coId = mappingsDTO.getCo_id();
                String poId = mappingsDTO.getPo_id();

                // Decide which cell of the returned excel sheet to input the strength value into 
                // co_id is in the form co1, co2, etc., and po_id is in the form po1, po2, etc.
                int coNumber = Integer.parseInt(coId.substring(2)); // Extract the numerical part after "co"
                int poNumber = Integer.parseInt(poId.substring(2)); // Extract the numerical part after "po"
                
                System.out.println("coId: " + coId + ", poId: " + poId + ", coNumber: " + coNumber + ", poNumber: " + poNumber);

                // Convert the column index to Excel column letter
                char excelColumnLetter = (char) ('R' + poNumber - 1); // 'r' corresponds to 1

                // Calculate the row and column indices
                int baseRow = 4;  // Starting row of the table for CO-PO mapping
                int baseColumn = 18;  // Starts from column R
                int rowIndex = baseRow + coNumber - 1;  
                int colIndex = baseColumn + poNumber - 1;  

                System.out.println("rowIndex: " + rowIndex + ", colIndex: " + colIndex);

	             // Get the cell in the modifiedFile
	             Row row = modifiedFile.getRow(rowIndex);
	             if (row == null) {
	                 System.out.println("Row is null");
	             } else {
	                 Cell cell = row.getCell(colIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
	                 if (cell == null) {
	                     System.out.println("Cell is null");
	                 } else {
	                	 System.out.println("Cell coordinates: col:" + cell.getColumnIndex() + "row:"+ cell.getRowIndex());
	                     System.out.println("Cell Value Before: " + cell.getNumericCellValue());
	                     int strengthValue = mappingsDTO.getStrength();
	                     cell.setCellValue(strengthValue);
	                     System.out.println("Cell Value After: " + cell.getNumericCellValue());
	                 }
	             }
            }
                            
        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
        }
    }

    @Override
    public File getModifiedFile() {
        String filePath = "D:\\COCOPO-project\\sts-4.20.0.RELEASE\\uploadsToWebsite\\Modified_Formula_template.xlsx";

        // Create a File object with the specified path
        File modifiedFile = new File(filePath);

        // Check if the file exists
        if (modifiedFile.exists()) {
            return modifiedFile;
        } else {
            System.out.println("File not found: " + filePath);
            return null;
        }
    }


    // Define a method to evaluate the formula in a cell and return the result as a float
    private float evaluateCellFormula(Cell cell, FormulaEvaluator formulaEvaluator) {
        CellValue cellValue = formulaEvaluator.evaluate(cell);

        switch (cellValue.getCellType()) {
            case NUMERIC:
                return (float) cellValue.getNumberValue();
            case STRING:
                // Handle if the result is a string, you can convert it to float if it's not empty
                String stringValue = cellValue.getStringValue();
                if (!stringValue.isEmpty()) {
                    try {
                        return Float.parseFloat(stringValue);
                    } catch (NumberFormatException e) {
                        // Handle the conversion failure if needed
                        e.printStackTrace();
                    }
                }
                return 0.0f; // Default value for empty or failed conversion
            default:
                return 0.0f; // Default value for other cell types
        }
    }

    /*
	int currentYear = Year.now().getValue();
	
	// For Course Attainment
	// Calculate the row and column indices
	baseRow = 18;  // Starting row of the table for Course and Program Attainment
	rowIndex = baseRow + coNumber - 1;  
	colIndex = 17;  //column Q

	// Get the cell in the modifiedFile
	Row attainmentRow = modifiedFile.getRow(rowIndex);
	Cell cAttainmentCell = attainmentRow.getCell(colIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

	float cAttainmentValue = evaluateCellFormula(cAttainmentCell, formulaEvaluator);
	
    if (courseAttainmentList == null || courseAttainmentList.isEmpty()) {
        CourseAttainmentDTO cAttainmentDTO = new CourseAttainmentDTO();
        cAttainmentDTO.setYear(currentYear);
        cAttainmentDTO.setCourse_code(course_code);
        cAttainmentDTO.setCo_id(coId);
        cAttainmentDTO.setCourse_attainment(cAttainmentValue);
        
        cAttainmentServices.addCourseAttainment(cAttainmentDTO);
    } else {
        CourseAttainmentDTO cAttainmentDTO = cAttainmentServices.getByCourseAttainment(currentYear, coId, course_code);
        cAttainmentDTO.setCourse_attainment(cAttainmentValue);
        cAttainmentServices.updateCourseAttainment(cAttainmentDTO, currentYear, coId, course_code);
    }
    
    //For Program Attainment
    // same rowIndex and row
    baseColumn = 18; // starts from column R
    colIndex = excelColumnLetter - 'a' + baseColumn;  

    Cell pAttainmentCell = attainmentRow.getCell(colIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

	float pAttainmentValue = evaluateCellFormula(pAttainmentCell, formulaEvaluator);

    if (programAttainmentList == null || programAttainmentList.isEmpty()) {
        ProgramAttainmentDTO pAttainmentDTO = new ProgramAttainmentDTO();
        pAttainmentDTO.setYear(currentYear);
        pAttainmentDTO.setCourse_code(course_code);
        pAttainmentDTO.setCo_id(coId);
        pAttainmentDTO.setPo_id(poId);
        pAttainmentDTO.setProgram_attainment(pAttainmentValue);  
        
        pAttainmentServices.addProgramAttainment(pAttainmentDTO);
    } else {
        ProgramAttainmentDTO pAttainmentDTO = pAttainmentServices.getByProgramAttainment(currentYear, coId, poId, course_code);
        pAttainmentServices.updateProgramAttainment(pAttainmentDTO, currentYear, coId, poId, course_code);
    }
	*/
}
