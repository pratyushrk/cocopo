package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.CoRbtMappingsDTO;
import com.cocopo.services.CoRbtMappingServices;

@RestController
@RequestMapping("/api/co-rbt-mappings")
public class CoRbtMappingController {

	@Autowired
	private CoRbtMappingServices coRbtMappingServices;
	
    // POST - Add RBT Mappings
    @PostMapping("/")
    public ResponseEntity<CoRbtMappingsDTO> addRbtMappings(@RequestBody CoRbtMappingsDTO rbtMappingsDTO) {
        CoRbtMappingsDTO createdRbtMappingsDTO = this.coRbtMappingServices.addRbtMappings(rbtMappingsDTO);
        return new ResponseEntity<>(createdRbtMappingsDTO, HttpStatus.CREATED);
    }

    // PUT - Update RBT Mappings
    @PutMapping("/{course_code}/{co_id}")
    public ResponseEntity<List<CoRbtMappingsDTO>> updateRbtMappings(
            @PathVariable String course_code,
            @PathVariable String co_id,
            @RequestBody List<String> rbtList) {

        List<CoRbtMappingsDTO> updatedRbtMappingsDTO = this.coRbtMappingServices.updateRbtMappings(course_code, co_id, rbtList);
        return new ResponseEntity<>(updatedRbtMappingsDTO, HttpStatus.OK);
    }

    // GET - Get RBT Mappings by Code and CO_ID
    @GetMapping("/{course_code}/{co_id}")
    public ResponseEntity<List<String>> getRbtMappingsByCode(
            @PathVariable String course_code,
            @PathVariable String co_id) {

        List<String> rbtMappings = this.coRbtMappingServices.getRbtMappingsByCode(course_code, co_id);
        return new ResponseEntity<>(rbtMappings, HttpStatus.OK);
    }

    // DELETE - Delete RBT Mapping
    @DeleteMapping("/")
    public ResponseEntity<Void> deleteRbtMapping(@RequestBody CoRbtMappingsDTO rbtMappingsDTO) {
        this.coRbtMappingServices.deleteRbtMapping(rbtMappingsDTO);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    // DELETE - Delete All RBT Mappings
    @DeleteMapping("/{course_code}")
    public ResponseEntity<Void> deleteAllRbtMappings(@PathVariable String course_code) {
        this.coRbtMappingServices.deleteAllRbtMappings(course_code);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
}
