package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.CourseObjectiveDTO;
import com.cocopo.services.CourseObjectiveServices;

@RestController
@RequestMapping("/api/course-objectives")
public class CourseObjectiveController {

	@Autowired
    private CourseObjectiveServices objectiveServices;

    // POST
	@PostMapping("/")
    public ResponseEntity<CourseObjectiveDTO> createCourseObjectiveEntity(@RequestBody CourseObjectiveDTO cObjectiveDTO) {
        CourseObjectiveDTO createObjectiveDTO = this.objectiveServices.addCourseObjective(cObjectiveDTO);
        return new ResponseEntity<>(createObjectiveDTO, HttpStatus.CREATED);
    }

    // PUT
    @PutMapping("/{course_code}/{cobj_id}")
    public ResponseEntity<CourseObjectiveDTO> updateCourseObjectiveEntity(@RequestBody CourseObjectiveDTO objectiveDTO, @PathVariable("cobj_id") String cobj_id, @PathVariable("course_code") String course_code) {
    	CourseObjectiveDTO updateObjectiveDTO = this.objectiveServices.updateCourseObjective(objectiveDTO, cobj_id, course_code);
        return new ResponseEntity<>(updateObjectiveDTO, HttpStatus.OK);
    }

    // GET 
    @GetMapping("/{course_code}/{cobj_id}")
    public ResponseEntity<CourseObjectiveDTO> getExactCourseObjectivesEntity(@PathVariable("course_code") String course_code, @PathVariable("cobj_id") String cobj_id) {
        CourseObjectiveDTO getObjectiveDTO = this.objectiveServices.getExactCourseObjectiveByCourseCode(course_code, cobj_id);
        return new ResponseEntity<>(getObjectiveDTO, HttpStatus.OK);
    }
    
    @GetMapping("/{course_code}")
    public ResponseEntity<List<CourseObjectiveDTO>> getCourseObjectivesEntity(@PathVariable String course_code) {
        List<CourseObjectiveDTO> getObjectiveDTOs = this.objectiveServices.getCourseObjectiveByCourseCode(course_code);
        return new ResponseEntity<>(getObjectiveDTOs, HttpStatus.OK);
    }
    
    // DELETE
    @DeleteMapping("/{course_code}")
    public ResponseEntity<Void> deleteAllObjectivesEntity(@PathVariable String course_code) {
        this.objectiveServices.deleteAllCourseObjective(course_code);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
}
