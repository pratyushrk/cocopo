package com.cocopo.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.ProgramAttainmentDTO;
import com.cocopo.services.ProgramAttainmentServices;

@RestController
@RequestMapping("/api/program-attainment")
public class ProgramAttainmentController {

	@Autowired
	private ProgramAttainmentServices pAttainmentServices;
	
	// POST
    @PostMapping("/")
    public ResponseEntity<ProgramAttainmentDTO> createProgramAttainmentEntity(@RequestBody ProgramAttainmentDTO pAttainmentDTO) {
    	ProgramAttainmentDTO createPAttainmentDTO = this.pAttainmentServices.addProgramAttainment(pAttainmentDTO);
        return new ResponseEntity<>(createPAttainmentDTO, HttpStatus.CREATED);
    }

    // PUT
    @PutMapping("/{year}/{co_id}/{po_id}/{course_code}")
    public ResponseEntity<ProgramAttainmentDTO> updateProgramAttainmentEntity(@RequestBody ProgramAttainmentDTO pAttainmentDTO, @PathVariable("year") int year, @PathVariable("co_id") String co_id, @PathVariable("po_id") String po_id, @PathVariable("course_code") String course_code) {
    	ProgramAttainmentDTO updatePAttainmentDTO = this.pAttainmentServices.updateProgramAttainment(pAttainmentDTO, year, co_id, po_id, course_code);
        return new ResponseEntity<>(updatePAttainmentDTO, HttpStatus.OK);
    }

    // GET 
    @GetMapping("/{course_code}")
    public ResponseEntity<ProgramAttainmentDTO> getProgramAttainmentEntity(@PathVariable("year") int year, @PathVariable("co_id") String co_id, @PathVariable("po_id") String po_id, @PathVariable("course_code") String course_code) {
        ProgramAttainmentDTO getPAttainmentDTOs = this.pAttainmentServices.getByProgramAttainment(year, co_id, po_id, course_code);
        return new ResponseEntity<>(getPAttainmentDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/byCode/{course_code}")
    public ResponseEntity<List<ProgramAttainmentDTO>> getProgramAttainmentEntityByCode(@PathVariable String course_code) {
        List<ProgramAttainmentDTO> getPAttainmentDTOs = this.pAttainmentServices.getProgramAttainmentByCourseCode(course_code);
        return new ResponseEntity<>(getPAttainmentDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/{year}")
    public ResponseEntity<List<ProgramAttainmentDTO>> getProgramAttainmentEntityByYear(@PathVariable int year) {
        List<ProgramAttainmentDTO> getPAttainmentDTOs = this.pAttainmentServices.getProgramAttainmentByYear(year);
        return new ResponseEntity<>(getPAttainmentDTOs, HttpStatus.OK);
    }
    
    // DELETE
    @DeleteMapping("/")
    public ResponseEntity<?> deleteAllProgramAttainmentEntity(@PathVariable String course_code) {
        this.pAttainmentServices.deleteAllProgramAttainment(course_code);
        return new ResponseEntity<Object>(Map.of("message", "Deleted Successfully") ,HttpStatus.OK); 
    }
	
}
