package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.CourseAttainmentDTO;
import com.cocopo.services.CourseAttainmentServices;

@RestController
@RequestMapping("/api/course-attainment")
public class CourseAttainmentControllers {

	@Autowired
	private CourseAttainmentServices cAttainmentServices;
	
	// POST
    @PostMapping("/")
    public ResponseEntity<CourseAttainmentDTO> createCourseAttainmentEntity(@RequestBody CourseAttainmentDTO cAttainmentDTO) {
    	CourseAttainmentDTO createCAttainmentDTO = this.cAttainmentServices.addCourseAttainment(cAttainmentDTO);
        return new ResponseEntity<>(createCAttainmentDTO, HttpStatus.CREATED);
    }

    // PUT
    @PutMapping("/{year}/{co_id}/{course_code}")
    public ResponseEntity<CourseAttainmentDTO> updateCourseAttainmentEntity(@RequestBody CourseAttainmentDTO cAttainmentDTO, @PathVariable("year") int year, @PathVariable("co_id") String co_id, @PathVariable("course_code") String course_code) {
    	CourseAttainmentDTO updateCAttainmentDTO = this.cAttainmentServices.updateCourseAttainment(cAttainmentDTO, year, co_id, course_code);
        return new ResponseEntity<>(updateCAttainmentDTO, HttpStatus.OK);
    }

    // GET 
    @GetMapping("/{year}/{co_id}/{course_code}")
    public ResponseEntity<CourseAttainmentDTO> getCourseAttainmentEntity(@PathVariable("year") int year, @PathVariable("co_id") String co_id, @PathVariable("course_code") String course_code) {
        CourseAttainmentDTO getCAttainmentDTOs = this.cAttainmentServices.getByCourseAttainment(year, co_id, course_code);
        return new ResponseEntity<>(getCAttainmentDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/{course_code}")
    public ResponseEntity<List<CourseAttainmentDTO>> getCourseAttainmentEntityByCode(@PathVariable String course_code) {
        List<CourseAttainmentDTO> getCAttainmentDTOs = this.cAttainmentServices.getCourseAttainmentByCourseCode(course_code);
        return new ResponseEntity<>(getCAttainmentDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/{year}")
    public ResponseEntity<List<CourseAttainmentDTO>> getCourseAttainmentEntityByYear(@PathVariable int year) {
        List<CourseAttainmentDTO> getCAttainmentDTOs = this.cAttainmentServices.getCourseAttainmentByYear(year);
        return new ResponseEntity<>(getCAttainmentDTOs, HttpStatus.OK);
    }
    
    // DELETE
    @DeleteMapping("/")
    public ResponseEntity<Void> deleteAllCourseAttainmentEntity(@PathVariable String course_code) {
        this.cAttainmentServices.deleteAllCourseAttainment(course_code);
        return new ResponseEntity<>(HttpStatus.OK);
    }
	
}
