package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.UserCourseDTO;
import com.cocopo.services.UserCourseServices;

@RestController
@RequestMapping("/api/users-courses")
public class UserCourseController {

	@Autowired
    private UserCourseServices userCourseServices;

    // POST
    @PostMapping("/")
    public ResponseEntity<UserCourseDTO> createUserCourseEntity(@RequestBody UserCourseDTO userCourseDTO) {
        UserCourseDTO createUserCourseDTO = this.userCourseServices.addUserCourse(userCourseDTO);
        return new ResponseEntity<>(createUserCourseDTO, HttpStatus.CREATED);
    }

    // PUT
    @PutMapping("/{assigned_faculty}/{course_code}")
    public ResponseEntity<UserCourseDTO> updateUserCourseEntity(@RequestBody UserCourseDTO userCourseDTO, @PathVariable("assigned_faculty") String assigned_faculty, @PathVariable("course_code") String course_code) {
    	UserCourseDTO updateUserDTO = this.userCourseServices.updateUserCourse(userCourseDTO, assigned_faculty, course_code);
        return new ResponseEntity<>(updateUserDTO, HttpStatus.OK);
    }

    // GET 
    @GetMapping("/{course_code}")
    public ResponseEntity<List<UserCourseDTO>> getUserCourseByCourseEntity(@PathVariable("course_code") String course_code) {
        List<UserCourseDTO> getUserDTO = this.userCourseServices.getUserByCourse(course_code);
        return new ResponseEntity<>(getUserDTO, HttpStatus.OK);
    }
    
    @GetMapping("/staff/{assigned_faculty}")
    public ResponseEntity<List<UserCourseDTO>> getUserCourseByIdEntity(@PathVariable("assigned_faculty") String assigned_faculty) {
        List<UserCourseDTO> getUserDTO = this.userCourseServices.getUserByCourse(assigned_faculty);
        return new ResponseEntity<>(getUserDTO, HttpStatus.OK);
    }
    
    @GetMapping("/")
    public ResponseEntity<List<UserCourseDTO>> getAllUserCourseEntity() {
        List<UserCourseDTO> getAllUserCourseDTOs = this.userCourseServices.getAllUserCourses();
        return new ResponseEntity<>(getAllUserCourseDTOs, HttpStatus.OK);
    }

    // DELETE
    @DeleteMapping("/")
    public ResponseEntity<Void> deleteUserEntity(@RequestBody UserCourseDTO userCourseDTO) {
        this.userCourseServices.deleteUserCourse(userCourseDTO);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
}
