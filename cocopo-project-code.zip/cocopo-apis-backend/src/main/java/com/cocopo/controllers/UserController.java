package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.UserDTO;
import com.cocopo.services.UserServices;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserServices userServices;

    // POST - create user
    @PostMapping("/")
    public ResponseEntity<UserDTO> createUserEntity(@RequestBody UserDTO userDto) {
        UserDTO createUserDTO = this.userServices.addUser(userDto);
        return new ResponseEntity<>(createUserDTO, HttpStatus.CREATED);
    }

    // PUT - update user
    @PutMapping("/{username}")
    public ResponseEntity<UserDTO> updateUserEntity(@RequestBody UserDTO userDTO, @PathVariable String username) {
        UserDTO updateUserDTO = this.userServices.updateUser(userDTO, username);
        return new ResponseEntity<>(updateUserDTO, HttpStatus.OK);
    }

    // GET - get user
    @GetMapping("/")
    public ResponseEntity<List<UserDTO>> getAllUserEntity(){
    	List<UserDTO> getUserDTO = this.userServices.getAllUsers();
        return new ResponseEntity<>(getUserDTO, HttpStatus.OK);
    }
    
    @GetMapping("/{username}")
    public ResponseEntity<List<UserDTO>> getUserByIdEntity(@PathVariable String username) {
        List<UserDTO> getUserDTO = this.userServices.getUserById(username);
        return new ResponseEntity<>(getUserDTO, HttpStatus.OK);
    }
    
    @GetMapping("/name/{fullname}")
    public ResponseEntity<List<UserDTO>> getUserByNameEntity(@PathVariable String fullname) {
        List<UserDTO> getUserDTO = this.userServices.getUserByName(fullname);
        return new ResponseEntity<>(getUserDTO, HttpStatus.OK);
    }

    // DELETE - delete user
    @DeleteMapping("/{username}")
    public ResponseEntity<Void> deleteUserEntity(@PathVariable String username) {
        this.userServices.deleteUser(username);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}

