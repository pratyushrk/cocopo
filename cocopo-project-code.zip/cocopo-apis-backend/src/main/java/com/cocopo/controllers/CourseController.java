package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.CourseDTO;
import com.cocopo.services.CourseServices;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

	@Autowired
    private CourseServices courseServices;

    // POST
    @PostMapping("/")
    public ResponseEntity<CourseDTO> createUserCourseEntity(@RequestBody CourseDTO courseDTO) {
        CourseDTO createCourseDTO = this.courseServices.addCourse(courseDTO);
        return new ResponseEntity<>(createCourseDTO, HttpStatus.CREATED);
    }

    // PUT
    @PutMapping("/{course_code}")
    public ResponseEntity<CourseDTO> updateUserCourseEntity(@RequestBody CourseDTO courseDTO, @PathVariable String course_code) {
    	CourseDTO updateCourseDTO = this.courseServices.updateCourse(courseDTO, course_code);
        return new ResponseEntity<>(updateCourseDTO, HttpStatus.OK);
    }

    // GET 

    @GetMapping("/")
    public ResponseEntity<List<CourseDTO>> getAllCourseEntity() {
        List<CourseDTO> getAllUserCourseDTOs = this.courseServices.getAllCourses();
        return new ResponseEntity<>(getAllUserCourseDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/{branch}")
    public ResponseEntity<List<CourseDTO>> getCourseEntityByBranch(@PathVariable String branch) {
        List<CourseDTO> getCourseDTOs = this.courseServices.getCourseByBranch(branch);
        return new ResponseEntity<>(getCourseDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/code/{course_code}")
    public ResponseEntity<List<CourseDTO>> getCourseEntityByCode(@PathVariable String course_code) {
        List<CourseDTO> getCourseDTOs = this.courseServices.getCourseByCode(course_code);
        return new ResponseEntity<>(getCourseDTOs, HttpStatus.OK);
    }
    
    @PostMapping("/codeList")
    public ResponseEntity<List<CourseDTO>> getCourseEntityByCodeList(@RequestBody List<String> courseCodeList) {
        List<CourseDTO> getCourseDTOs = this.courseServices.getCourseByCodeList(courseCodeList);
        return new ResponseEntity<>(getCourseDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/name/{course_name}")
    public ResponseEntity<List<CourseDTO>> getUserCourseEntityByName(@PathVariable String course_name) {
        List<CourseDTO> getCourseDTOs = this.courseServices.getCourseByName(course_name);
        return new ResponseEntity<>(getCourseDTOs, HttpStatus.OK);
    }
    
    // DELETE
    @DeleteMapping("/")
    public ResponseEntity<Void> deleteUserEntity(@RequestBody CourseDTO courseDTO) {
        this.courseServices.deleteCourse(courseDTO);
        return new ResponseEntity<>(HttpStatus.OK);
    }
	
}
