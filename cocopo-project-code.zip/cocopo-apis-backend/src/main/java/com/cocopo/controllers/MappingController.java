package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.MappingsDTO;
import com.cocopo.services.MappingServices;

@RestController
@RequestMapping("/api/mappings")
public class MappingController {
	
	@Autowired
	private MappingServices mappingServices;

    @PostMapping("/")
    public ResponseEntity<MappingsDTO> addMappingEntity(@RequestBody MappingsDTO mappingDto) {
        MappingsDTO createdMappingDTO = this.mappingServices.addMapping(mappingDto);
        return new ResponseEntity<>(createdMappingDTO, HttpStatus.CREATED);
    }

    // PUT - Update Mapping
    @PutMapping("/{course_code}/{co_id}/{po_id}")
    public ResponseEntity<MappingsDTO> updateMappingEntity(
            @RequestBody MappingsDTO mappingDto,
            @PathVariable String course_code,
            @PathVariable String co_id,
            @PathVariable String po_id) {

        MappingsDTO updatedMappingDTO = this.mappingServices.updateMapping(mappingDto, course_code, co_id, po_id);
        return new ResponseEntity<>(updatedMappingDTO, HttpStatus.OK);
    }

    // GET - Get Mappings by Course Code
    @GetMapping("/{course_code}")
    public ResponseEntity<List<MappingsDTO>> getMappingsByCourseCode(@PathVariable String course_code) {
        List<MappingsDTO> mappingDTOs = this.mappingServices.getMappingsByCourseCode(course_code);
        return new ResponseEntity<>(mappingDTOs, HttpStatus.OK);
    }

    // DELETE - Delete Mapping
    @DeleteMapping("/")
    public ResponseEntity<Void> deleteMapping(@RequestBody MappingsDTO mappingsDTO) {
        this.mappingServices.deleteMapping(mappingsDTO);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    // DELETE - Delete All Mappings
    @DeleteMapping("/{course_code}")
    public ResponseEntity<Void> deleteAllMappings(@PathVariable String course_code) {
        this.mappingServices.deleteAllMapping(course_code);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
}
