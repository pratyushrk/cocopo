package com.cocopo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cocopo.services.StudentMarkServices;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.UUID;


@RestController
@RequestMapping("/api/marks")
public class StudentMarksController {
	
	@Autowired
	private StudentMarkServices markServices;
	
	
	@PostMapping("/calculate")
    public ResponseEntity<Void> calculateAllAttainmentsEntity(
            @RequestParam("uploadedFile") MultipartFile uploadedFile,
            @RequestParam("course_code") String courseCode) {
        try {
            // Ensure that the file is not empty
            if (uploadedFile == null || uploadedFile.isEmpty()) {
                return ResponseEntity.badRequest().body(null); // Return a 400 Bad Request response
            }

         // Assuming you have a directory path where you want to save the files
            String uploadDirectory = "D:\\COCOPO-project\\sts-4.20.0.RELEASE\\uploadsToWebsite";

            // Create the directory if it doesn't exist
            File directory = new File(uploadDirectory);
            if (!directory.exists()) {
                directory.mkdirs();
            }

            // Save the uploaded file with a proper file name
            String originalFilename = uploadedFile.getOriginalFilename();
            String uniqueFilename = generateUniqueFileName(originalFilename);
            File savedFile = new File(directory.getAbsolutePath() + File.separator + uniqueFilename);

            // Use transferTo directly on the MultipartFile
            uploadedFile.transferTo(savedFile);


            markServices.calculateAllAttainments(savedFile, courseCode);

        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); // Return a 500 Internal Server Error response
        }
        return null;
    }

	private String generateUniqueFileName(String fileName) {
        // Generate a unique file name, for example, using a UUID.
        String extension = "";
        int dotIndex = fileName.lastIndexOf(".");	//extension is the part after *last* dot
        if (dotIndex != -1) {	//dotIndex=-1 means no dot or extension
            extension = fileName.substring(dotIndex);	//save the substring after dot as the extension
        }
        return UUID.randomUUID().toString() + extension;	//join the 128-bit generated *unique* identifier and extension and return 
    }

	@GetMapping("/download")
	public ResponseEntity<Resource> getModifiedFileEntity() {
	    File modifiedFile = markServices.getModifiedFile();

	    if (modifiedFile == null || !modifiedFile.exists()) {
	        return ResponseEntity.notFound().build();
	    }

	    try (FileInputStream fileInputStream = new FileInputStream(modifiedFile)) {
	        InputStreamResource resource = new InputStreamResource(fileInputStream);

	        HttpHeaders headers = new HttpHeaders();
	        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=marks_with_formulas.xlsx");

	        return ResponseEntity.ok()
	                .headers(headers)
	                .contentLength(modifiedFile.length())
	                .contentType(MediaType.APPLICATION_OCTET_STREAM)
	                .body(resource);

	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	    } catch (IOException e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	    }
	}

	
}
