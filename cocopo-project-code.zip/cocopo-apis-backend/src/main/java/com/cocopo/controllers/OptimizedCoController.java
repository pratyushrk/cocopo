package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.OptimizedCoDTO;
import com.cocopo.services.OptimizedCoServices;

@RestController
@RequestMapping("/api/optimized-co")
public class OptimizedCoController {

    @Autowired
    private OptimizedCoServices optimizedCoServices;

    @PostMapping("/runJupyterNotebook")
    public void runJupyterNotebook(@RequestBody List<String> coList) {
        // Call your existing method
    	optimizedCoServices.RunJupyterNotebook(coList);
    }
    
    // POST - Add Optimized CO
    @PostMapping("/")
    public ResponseEntity<OptimizedCoDTO> addOptimizedCO(@RequestBody OptimizedCoDTO coDTO) {
        OptimizedCoDTO addedOptimizedCO = this.optimizedCoServices.addOptimizedCO(coDTO);
        return new ResponseEntity<>(addedOptimizedCO, HttpStatus.CREATED);
    }

    // PUT - Update Optimized CO Status
    @PutMapping("/{course_code}/{co_id}/{optimized_id}")
    public ResponseEntity<OptimizedCoDTO> updateOptimizedCOStatus(@PathVariable("course_code") String course_code, @PathVariable("co_id") String co_id, @PathVariable("optimized_id") int optimized_id) {
        OptimizedCoDTO updatedOptimizedCO = this.optimizedCoServices.updateStatus(course_code, co_id, optimized_id);
        return new ResponseEntity<>(updatedOptimizedCO, HttpStatus.OK);
    }

    // GET - Get Selected Optimized CO
    @GetMapping("/{co_id}")
    public ResponseEntity<List<OptimizedCoDTO>> getOptimizedCoByCodeEntity(@PathVariable String co_id) {
        List<OptimizedCoDTO> optimizedCoDTOs = this.optimizedCoServices.getOptimizedCOByCode(co_id);
        return new ResponseEntity<>(optimizedCoDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/selected/{co_id}")
    public ResponseEntity<OptimizedCoDTO> getSelectedOptimizedCO(@PathVariable String co_id) {
        OptimizedCoDTO selectedOptimizedCO = this.optimizedCoServices.getSelectedOptimizedCO(co_id);
        return new ResponseEntity<>(selectedOptimizedCO, HttpStatus.OK);
    }

    // GET - Get All Selected Optimized COs for a Course
    @GetMapping("/")
    public ResponseEntity<List<OptimizedCoDTO>> getAllSelectedOptimizedCOs() {
        List<OptimizedCoDTO> allSelectedOptimizedCOs = this.optimizedCoServices.getAllSelectedOptimizedCOs();
        return new ResponseEntity<>(allSelectedOptimizedCOs, HttpStatus.OK);
    }

    // DELETE - Delete All Optimized COs
    @DeleteMapping("/")
    public ResponseEntity<Void> deleteAllOptimizedCo() {
        this.optimizedCoServices.deleteAllOptimizedCo();
        return new ResponseEntity<>(HttpStatus.OK);
    }
}

