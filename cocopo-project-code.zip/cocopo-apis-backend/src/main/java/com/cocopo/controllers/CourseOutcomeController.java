package com.cocopo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cocopo.payloads.CourseOutcomeDTO;
import com.cocopo.services.CourseOutcomeServices;

@RestController
@RequestMapping("/api/course-outcomes")
public class CourseOutcomeController {

	@Autowired
    private CourseOutcomeServices outcomeServices;

    // POST
    @PostMapping("/")
    public ResponseEntity<CourseOutcomeDTO> createCourseOutcomeEntity(@RequestBody CourseOutcomeDTO outcomeDTO) {
    	CourseOutcomeDTO createOutcomeDTO = this.outcomeServices.addCourseOutcome(outcomeDTO);
        return new ResponseEntity<>(createOutcomeDTO, HttpStatus.CREATED);
    }

    // PUT
    @PutMapping("/{course_code}/{co_id}")
    public ResponseEntity<CourseOutcomeDTO> updateCourseOutcomeEntity(@RequestBody CourseOutcomeDTO outcomeDTO, @PathVariable("co_id") String co_id, @PathVariable("course_code") String course_code) {
    	CourseOutcomeDTO updateOutcomeDTO = this.outcomeServices.updateCourseOutcome(outcomeDTO, co_id, course_code);
        return new ResponseEntity<>(updateOutcomeDTO, HttpStatus.OK);
    }

    // GET 
    @GetMapping("/{course_code}/{co_id}")
    public ResponseEntity<CourseOutcomeDTO> getExactCourseOutcomeEntity(@PathVariable("course_code") String course_code, @PathVariable("co_id") String co_id){
    	CourseOutcomeDTO getOutcomeDTO = this.outcomeServices.getExactCourseOutcomeByCourseCode(course_code, co_id);
    	return new ResponseEntity<>(getOutcomeDTO, HttpStatus.OK);
    }
    
    @GetMapping("/{course_code}")
    public ResponseEntity<List<CourseOutcomeDTO>> getCourseOutcomeEntity(@PathVariable String course_code) {
        List<CourseOutcomeDTO> getOutcomeDTOs = this.outcomeServices.getCourseOutcomeByCourseCode(course_code);
        return new ResponseEntity<>(getOutcomeDTOs, HttpStatus.OK);
    }

    // DELETE
    @DeleteMapping("/{course_code}")
    public ResponseEntity<Void> deleteAllOutcomesEntity(@PathVariable String course_code) {
        this.outcomeServices.deleteAllCourseOutcome(course_code);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
}
